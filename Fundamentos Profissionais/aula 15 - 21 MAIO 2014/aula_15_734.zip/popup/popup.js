window.onload = iniciar;

function iniciar(){
	/* Teste: muda a cor do  fundo do corpo para preto */
	//document.body.style.backgroundColor = "black";
	
	document.getElementById("b1").onclick = mostraPopUp;
	document.getElementById("b2").onclick = escondePopUp;
}

function mostraPopUp(){
	/* Teste: muda a cor do  fundo do corpo para preto */
	//document.body.style.backgroundColor = "black";
	document.getElementById("d1").style.visibility = "visible";
}

function escondePopUp(){
	document.getElementById("d1").style.visibility = "hidden";
}