
// quando o navegador terminar de carregar TODO o html executa a fun��o iniciar().
window.onload = iniciar;

function iniciar() {
	var  botao = document.getElementById("mudacor");
	botao.onclick = mudaCorDeFundo;
	// as duas linhas acima tamb�m poderiam ser substituidas por: document.getElementById("mudacor").onclick = mudaCorDeFundo;
	// entretanto, como n�s usamos o mesmo elemento mais de uma vez na mesma fun��o o "apelidamos" de "botao".
	botao.onmouseover = mostraAjuda;
	botao.onmouseout = limpaAjuda;
}

function mudaCorDeFundo() {
	document.body.style.backgroundColor = "blue";
	// a linha abaixo altera a fun��o que � chamada quando clicarmos no elemento "mudacor"
	document.getElementById("mudacor").onclick = mudaCorDeFundo2;
}

function mudaCorDeFundo2() {
	document.body.style.backgroundColor = "white";
	// a linha abaixo altera a fun��o que � chamada quando clicarmos no elemento "mudacor"
	document.getElementById("mudacor").onclick = mudaCorDeFundo;
}

function mostraAjuda() {
	var texto = document.getElementById("ajuda");
	texto.innerHTML = "Clique para trocar de cor!!";
}

function limpaAjuda() {
	var texto = document.getElementById("ajuda");
	texto.innerHTML = "<br/>";
}