
/* Inicializa o Documento */
window.onload = iniciar;
function iniciar() {
	document.getElementById("formCadastro").onsubmit = validar;
}

/* Valida Formul�rio */
function validar() {
   /* Cria vari�vel para o formul�rio */
   var formCadastro = document.getElementById("formCadastro");

   /* Checa se nome est� preenchido */
   if (formCadastro.nome.value.length == 0) {
   /* Forma alternativa: if (document.getElementById("nome").value.length == 0) { */
      mostraTexto("Voc� precisa digitar um nome!");
      return false;
    }
   /* Checa se nome tem tamanho m�nimo de 6 chars */
   if (formCadastro.nome.value.length < 6) {
      mostraTexto("Nome muito curto!");
     return false;
    }
   /* Checa se idade � um n�mero */
   if (isNaN(formCadastro.idade.value)) {
      mostraTexto("A idade precisa ser um n�mero!");
      return false;
    }
   /* Checa se idade � maior que 18 anos */
   if (formCadastro.idade.value < 18) {
      mostraTexto("A idade m�nima � 18 anos!");
      return false;
    }
   /* Checa se idade � maior que 150 anos */
   if (formCadastro.idade.value > 150) {
      mostraTexto("Ningu�m vive tanto tempo!");
      return false;
    }
   /* Checa se mensagem foi digitada */
   if (formCadastro.msg.value.length < 1) {
      mostraTexto("Mensagem muito curta!");
      return false;
    }
   return true;
}


/* Fun��o auxiliar usada para informar erros no preenchimento */
function mostraTexto(text) {
	document.getElementById("ajuda").style.color = "red";
	document.getElementById("ajuda").innerHTML = text;
}