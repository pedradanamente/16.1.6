window.onload = iniciar;
//window.setInterval('mostraMensagem()',3000);
//window.setInterval('escondeMensagem()',3000);

function iniciar() {
	var botao = document.getElementById('mudacor');
	botao.ondblclick = mudaCorDeFundo;
	botao.onmouseover = mostraMensagem;
	botao.onmouseout = escondeMensagem;

	document.getElementById('aumentafonte').onclick = aumentaFonte;
	document.getElementById('diminuifonte').onclick = diminuiFonte;
}

function mudaCorDeFundo() {
	// troca o fundo do elemento body
	document.body.style.backgroundColor = "#c00";
	//alert('Trocamos a cor do fundo!');
}

function mostraMensagem() {
	// mostra a mensagem de ajuda
	var ajuda = document.getElementById('ajuda');
	ajuda.innerHTML = "<strong style='color:blue;'>Clique para trocar a cor do fundo</strong> <input type='button' value='CLIQUE SE PUDER'>";
}

function escondeMensagem() {
	// esconde a mensagem de ajuda
	var ajuda = document.getElementById('ajuda');
	ajuda.innerHTML = '<br>';
}

function aumentaFonte() {
	var tamanho_atual = document.getElementById('texto').style.fontSize;
	var vetor = tamanho_atual.split('px');
	var novo_tamanho = parseInt(vetor[0]) + 4;
	document.getElementById('texto').style.fontSize = novo_tamanho + 'px';
}

function diminuiFonte() {
	var tamanho_atual = document.getElementById('texto').style.fontSize;
	var vetor = tamanho_atual.split('px');
	var novo_tamanho = parseInt(vetor[0]) - 4;
	document.getElementById('texto').style.fontSize = novo_tamanho + 'px';
}

