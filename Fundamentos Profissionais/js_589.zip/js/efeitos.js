alert('olá mundo!');

function mudaCorDeFundo() {
	// define o elemento body como fundo azul
	document.body.style.backgroundColor = "#c00";
}

function abrePopUp() {
	// abre a popup chata para o usuario
}

function fechaPopUp() {
	// deixa o usuario fechar a popup chata
}

