﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banco
{
    public class BDCliente : BDBase
    {


        public bool Salvar(Cliente objClie)
        {
            int ret = 0;
            //string strCon = "Data Source=localhost;Initial catalog=LC;User Id=lc;password=123";
            //classe para conexão com banco
            //con = Conexao.Conectar();
            //classe para realizar os comandos entre app vs. banco
            string sql = "INSERT INTO cliente (nome,cpf) values (@nome,@cpf)";
            SqlCommand cmd = new SqlCommand(sql, con);
            //adicionar parametro que é usado no comando sql
            cmd.Parameters.AddWithValue("@nome", objClie.Nome);
            cmd.Parameters.AddWithValue("@cpf", objClie.Cpf);
            try
            {
                //abrir conexão com banco
                con.Open();
                //executar comando e capturar nro de linhas afetadas
                ret = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                //"passar adiante" erro de exceção
                throw new Exception(ex.Message);
            }
            finally
            {
                //verificar se conexão está aberta...e se sim...fechar
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return ret > 0;
        }

        public bool Atualizar(Cliente objeto)
        {
            int ret = 0;
            
            string sql = "UPDATE cliente SET nome=@nome, cpf=@cpf where id=@id";
            SqlCommand cmd = new SqlCommand(sql, con);
            //adicionar parametro que é usado no comando sql
            cmd.Parameters.AddWithValue("@nome", objeto.Nome);
            cmd.Parameters.AddWithValue("@cpf", objeto.Cpf);
            cmd.Parameters.AddWithValue("@id", objeto.Id);
            try
            {
                //abrir conexão com banco
                con.Open();
                //executar comando e capturar nro de linhas afetadas
                ret = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                //"passar adiante" erro de exceção
                throw new Exception(ex.Message);
            }
            finally
            {
                //verificar se conexão está aberta...e se sim...fechar
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return ret > 0;
        }

        public List<Cliente> Listar()
        {
            List<Cliente> objListCli = null;
            Cliente objCli = null;

            //string strCon = "Data source=localhost;Initial catalog=LC;user id=lc;password=123";
            //classe para conexão com banco
            //con = Conexao.Conectar();
            string sql = "select id,nome,cpf from cliente order by nome";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr;
            try
            {
                con.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    objListCli = new List<Cliente>();
                    while (dr.Read())
                    {
                        //instancio objeto cliente a cada item da lista de registos
                        objCli = new Cliente();
                        //leio as informações dos campos e jogo para o objeto
                        objCli.Id = Convert.ToInt16(dr["id"]);
                        objCli.Nome = dr["nome"].ToString();
                        objCli.Cpf = dr["cpf"].ToString();
                        //adiciono o objeto à lista
                        objListCli.Add(objCli);
                    }
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return objListCli;
        }

        public List<Cliente> Listar(int page, int pageSize)
        {
            List<Cliente> objListCli = null;
            Cliente objCli = null;

            string sql = null;
            if (page == 1)
                sql = "select top " + pageSize + " id,nome,cpf from cliente order by nome";
            else
            {
                int PreviousPageOffSet = (page - 1) * pageSize;
                sql = "select top " + pageSize + " id, nome, cpf from cliente WHERE id NOT IN " +
                        "(Select TOP " + PreviousPageOffSet + " id from cliente ORDER BY id) order by nome";
            }
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr;
            try
            {
                con.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    objListCli = new List<Cliente>();
                    while (dr.Read())
                    {
                        //instancio objeto cliente a cada item da lista de registos
                        objCli = new Cliente();
                        //leio as informações dos campos e jogo para o objeto
                        objCli.Id = Convert.ToInt16(dr["id"]);
                        objCli.Nome = dr["nome"].ToString();
                        objCli.Cpf = dr["cpf"].ToString();
                        //adiciono o objeto à lista
                        objListCli.Add(objCli);
                    }
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return objListCli;
        }

        public Cliente Buscar(int id)
        {
            Cliente objCli = null;

            string sql = "select id,nome,cpf from cliente where id=@id";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@id", id);
            SqlDataReader dr;
            try
            {
                con.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    //posiociona o cursor no próximo registro (no caso o primeiro)
                    dr.Read();
                    //instancio objeto cliente a cada item da lista de registos
                    objCli = new Cliente();
                    //leio as informações dos campos e jogo para o objeto
                    objCli.Id = Convert.ToInt16(dr["id"]);
                    objCli.Nome = dr["nome"].ToString();
                    objCli.Cpf = dr["cpf"].ToString();


                }
                dr.Close();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return objCli;
        }
    }
}
