﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banco
{
    public class Conexao
    {
        public static SqlConnection Conectar()
        {
            return new SqlConnection("Data source=localhost;Initial catalog=LC;user id=lc;password=123");
        }
    }
}
