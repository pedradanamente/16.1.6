﻿using Banco;
using Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    public class NGCliente
    {
        /// <summary>
        /// somente métodos...porque os atributos estão nas classes em /Entidades
        /// </summary>
        /// <param name="objClie"></param>
        /// <returns></returns>
        private bool Validar(Cliente objClie)
        {
            if (objClie.Nome.Length < 3)
                return false;
            else if (string.IsNullOrEmpty(objClie.Nome))
                return false;
            else if (objClie.Cpf.Length != 11)
                return false;
            else
                return true;
        }

        /// <summary>
        /// método para salvar os dados no banco
        /// </summary>
        /// <param name="objClie"></param>
        /// <returns></returns>
        public bool Salvar(Cliente objClie)
        {
            if (Validar(objClie))
            {
                BDCliente objBD = new BDCliente();
                return objBD.Salvar(objClie);
            }
            else return false;
        }

        /// <summary>
        /// Atualiza registro do objeto enviado 
        /// </summary>
        /// <param name="objeto">Instancia do objeto a ser atualizado</param>
        /// <returns>Retorna verdadeiro se atualizado com sucesso</returns>
        public bool Atualizar(Cliente objeto)
        {
            return new BDCliente().Atualizar(objeto);
        }

        /// <summary>
        /// método para retornar os registros salvos
        /// </summary>
        /// <returns>retorna uma lista de clientes</returns>
        public List<Cliente> Listar()
        {
            return new BDCliente().Listar();
        }
        
        /// <summary>
        /// método para retornar registros paginados
        /// </summary>
        /// <param name="page">pagina atual</param>
        /// <param name="pageSize">tamanho da pagina</param>
        /// <returns>retorna uma lista de clientes</returns>
        public List<Cliente> Listar(int page, int pageSize)
        {
            return new BDCliente().Listar(page, pageSize);
        }

        /// <summary>
        /// metodo para buscar um registro específico
        /// </summary>
        /// <param name="id">id para realizar a busca no banco</param>
        /// <returns>Retorna objeto cliente instanciado</returns>
        public Cliente Buscar(int id)
        {
            return new BDCliente().Buscar(id);
        }
    }
}
