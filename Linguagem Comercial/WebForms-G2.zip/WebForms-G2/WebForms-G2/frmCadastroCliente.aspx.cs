﻿using Entidades;
using Negocio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebForms_G2
{
    public partial class frmCadastroCliente : System.Web.UI.Page
    {
        int id;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
                CarregarGrid();
        }

        private void LimparForm()
        {
            txtNome.Text = "";
            txtCpf.Text = "";
            txtNome.Focus();
            btnAtualizar.Enabled = false;
            btnSalvar.Enabled = true;
        }

        private void CarregarGrid()
        {
            //limpar fonte de dados
            gvClientes.DataSource = null;
            //linkar fonte de dados com o gridview
            gvClientes.DataSource = new NGCliente().Listar();
            //invocar metodo de carregar dados da fonte com o controle
            gvClientes.DataBind();
        }

        protected void btnSalvar_Click(object sender, EventArgs e)
        {
            Cliente objCliente = new Cliente();
            objCliente.Nome = txtNome.Text;
            objCliente.Cpf = txtCpf.Text;
            try
            {
                if (new NGCliente().Salvar(objCliente))
                {
                    lblMensagem.Text = "Registro inserido";
                    LimparForm();
                    CarregarGrid();
                }
                else
                    lblMensagem.Text = "Erro ao inserir registro";
            }
            catch(Exception ex)
            {
                lblMensagem.Text = "Erro: " + ex.Message;
            }
        }

        protected void gvClientes_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvClientes.PageIndex = e.NewPageIndex;
            CarregarGrid();
        }

        protected void gvClientes_SelectedIndexChanged(object sender, EventArgs e)
        {
            id = int.Parse(gvClientes.SelectedRow.Cells[0].Text);
            Cliente objCliente = new NGCliente().Buscar(id);
            if (objCliente != null)
            {
                txtId.Text = id.ToString();
                txtCpf.Text = objCliente.Cpf;
                txtNome.Text = objCliente.Nome;
                btnAtualizar.Enabled = true;
                btnSalvar.Enabled = false;
            }
        }

        protected void btnAtualizar_Click(object sender, EventArgs e)
        {
            Cliente objCliente = new Cliente();
            objCliente.Nome = txtNome.Text;
            objCliente.Cpf = txtCpf.Text;
            objCliente.Id = int.Parse(txtId.Text);
            try
            {
                if (new NGCliente().Atualizar(objCliente))
                {
                    lblMensagem.Text = "Registro atualizado";
                    LimparForm();
                    CarregarGrid();
                }
                else
                    lblMensagem.Text = "Não foi possível inserir registro";
            }
            catch (Exception ex)
            {
                lblMensagem.Text = "erro:" + ex.Message;
            }
        }
    }
}