﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MDI
{
    public partial class frmCadCliente : Form
    {
        public string texto { get; set; }
        public frmCadCliente()
        {
            InitializeComponent();   
        }

        public frmCadCliente(string param)
        {
            InitializeComponent();
            this.Text = param;
        }

        
    }
}
