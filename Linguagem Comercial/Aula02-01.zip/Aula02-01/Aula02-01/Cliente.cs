﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula02_01
{
    class Cliente
    {
        public string Nome { get; set; }
        public decimal Salario { get; set; }
        public decimal Vale { get; set; }
    }
}
