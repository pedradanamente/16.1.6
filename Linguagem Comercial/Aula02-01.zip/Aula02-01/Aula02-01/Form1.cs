﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aula02_01
{
    public partial class Form1 : Form
    {
        //atributos


        public Form1()
        {
            InitializeComponent();
        }

        private bool DadosValidos(Cliente objCliente)
        {
            if (!string.IsNullOrEmpty(objCliente.Nome) && objCliente.Salario >= 0 && objCliente.Vale >= 0)
                return true;
            else
                return false;

        }

        private void btnClick_Click(object sender, EventArgs e)
        {
            //variaveis
            Cliente objCliente = new Cliente();

            objCliente.Nome = txtNome.Text;
            try
            {
                objCliente.Salario = Convert.ToDecimal(txtSalario.Text);

                objCliente.Vale = Convert.ToDecimal(txtVale.Text);

                objCliente.Salario += objCliente.Vale;

                if (DadosValidos(objCliente))
                    lblResultado.Text = objCliente.Nome + objCliente.Salario;
                else
                    lblResultado.Text = "Algum dado digitado errado!";

            }
            catch
            {
                lblResultado.Text = "Valores inválidos!";
            }

        }
    }
}
