﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Aula02_01_Web
{
    public partial class Form1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        private bool DadosValidos(Cliente objCliente)
        {
            if (!string.IsNullOrEmpty(objCliente.Nome) && objCliente.Salario >= 0 && objCliente.Vale >= 0)
                return true;
            else
                return false;

        }

        protected void btnClick_Click(object sender, EventArgs e)
        {
            Cliente objCliente = new Cliente();

            objCliente.Nome = txtNome.Text;
            try
            {
                objCliente.Salario = Convert.ToDecimal(txtSalario.Text);

                objCliente.Vale = Convert.ToDecimal(txtVale.Text);

                objCliente.Salario += objCliente.Vale;

                if (DadosValidos(objCliente))
                    lblResultado.Text = objCliente.Nome + objCliente.Salario;
                else
                    lblResultado.Text = "Algum dado digitado errado!";

            }
            catch
            {
                lblResultado.Text = "Valores inválidos!";
            }
        }
    }
}