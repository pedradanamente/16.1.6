﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Aula02_01_Web
{
    class Cliente
    {
        public string Nome { get; set; }
        public decimal Salario { get; set; }
        public decimal Vale { get; set; }
    }
}