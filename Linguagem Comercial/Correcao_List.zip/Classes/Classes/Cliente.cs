﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Classes
{
    public class Cliente
    {
        private string _nome;
        public string Cpf { get; set; }
        private DateTime? _nascimento = null;

        public string Nome
        {
            get { return _nome; }
            set { _nome = value; }
        }

        public DateTime? Nascimento()
        {
            return this._nascimento;
        }

        public void setNascimento(string data)
        {
            if (Validacoes.ValidarData(data))
                _nascimento = Convert.ToDateTime(data);
        }



        public void Validar()
        {
            try
            {
                if (string.IsNullOrEmpty(_nome))
                    throw new Exception("O nome deve ser preenchido");

                if (Cpf.Replace(".", "").Replace("-", "").Length != 11)
                    throw new Exception("Cpf inválido");

                if (_nascimento == null)
                    throw new Exception("Data invalida");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void Validar2()
        {

        }
    }
}
