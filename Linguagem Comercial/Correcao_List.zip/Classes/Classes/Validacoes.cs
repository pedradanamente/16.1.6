﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Classes
{
    public class Validacoes
    {
        public static bool ValidarData(string data)
        {
            try
            {
                Convert.ToDateTime(data);
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
