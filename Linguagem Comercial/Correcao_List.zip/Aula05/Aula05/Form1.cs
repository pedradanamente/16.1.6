﻿using Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aula05
{
    public partial class frmCadastroClientes : Form
    {
        //atributos
        //criar um arraylist do tipo cliente para alocar VÁRIOS clientes dentro
        List<Cliente> listCli = new List<Cliente>();


        //metodos
        public frmCadastroClientes()
        {
            InitializeComponent();
            
        }

        private void CarregarGrid()
        {
            //datagridview
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = listCli;
        }

        private void CarregarListView()
        {
            listView1.Items.Clear();
            StringBuilder sb = new StringBuilder();
            foreach (Cliente cli in listCli)
            {
                sb.Append("Nome: " + cli.Nome + Environment.NewLine);
                sb.Append("Cpf: " + cli.Cpf + Environment.NewLine);
                sb.Append("Nascimento: " + cli.Nascimento() + Environment.NewLine);
                sb.Append(Environment.NewLine);
                listView1.Items.Add(sb.ToString());
            }
        }

        private void CarregarListBox()
        {
            listBox1.Items.Clear();
            StringBuilder sb = new StringBuilder();
            foreach (Cliente cli in listCli)
            {
                sb.Append("Nome: " + cli.Nome + Environment.NewLine);
                sb.Append("Cpf: " + cli.Cpf + Environment.NewLine);
                sb.Append("Nascimento: " + cli.Nascimento() + Environment.NewLine);
                sb.Append(Environment.NewLine);
                listBox1.Items.Add(sb.ToString());
            }

        }

        

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            //criar um novo objeto para alocar os dados que serão inputados no form
            Cliente objCli = new Cliente();
            objCli.Nome = txtNome.Text;
            objCli.Cpf = txtCpf.Text;
            objCli.setNascimento(txtNascimento.Text);



            try
            {
                //validar os dados
                //se gerar exceção, vai para o catch
                objCli.Validar();

                //adicionar objeto cliente no arraylist
                listCli.Add(objCli);

                CarregarGrid();
                CarregarListBox();
                CarregarListView();
               


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


    }
}
