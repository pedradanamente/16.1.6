﻿using Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Aula05_web
{
    public partial class frmCadastroCliente : System.Web.UI.Page
    {
        //atributos
        List<Cliente> listCli = new List<Cliente>();


        //metodos
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["lista"] != null)
                listCli = (List<Cliente>)Session["lista"];
        }

        //carregar listbox com dados da lista de clientes do atributo do form
        private void CarregarListBox()
        {
            ListBox1.Items.Clear();
            foreach (Cliente cli in listCli)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("Nome: " + cli.Nome);
                sb.Append(" Cpf: " + cli.Cpf);
                sb.Append(" Nascimento: " + cli.Nascimento());

                ListBox1.Items.Add(sb.ToString());
            }
        }

        //carregar listbox2 com lista de clientes enviados por parametro
        private void CarregarListBox(List<Cliente> listParam)
        {
            ListBox2.Items.Clear();
            foreach (Cliente cli in listParam)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("Nome: " + cli.Nome);
                sb.Append(" Cpf: " + cli.Cpf);
                sb.Append(" Nascimento: " + cli.Nascimento());

                ListBox2.Items.Add(sb.ToString());
            }
        }

        //carregar listview com dados da lista de clientes do atributo do form
        private void CarregarListView()
        {
            
            ListView1.DataSource = null;
            ListView1.DataSource = listCli;
            ListView1.DataBind();
        }
        //carregar listview2 com lista de clientes enviados por parametro
        private void CarregarListView(List<Cliente> listParam)
        {

            ListView2.DataSource = null;
            ListView2.DataSource = listParam;
            ListView2.DataBind();
        }

        //carregar gridview com dados da lista de clientes do atributo do form
        private void CarregarGrid()
        {
            GridView1.DataSource = null;
            GridView1.DataSource = listCli;
            GridView1.DataBind();
        }
        //carregar gridview2 com lista de clientes enviados por parametro
        private void CarregarGrid(List<Cliente> listParam)
        {
            GridView2.DataSource = null;
            GridView2.DataSource = listParam;
            GridView2.DataBind();
        }

        protected void btnSalvar_Click(object sender, EventArgs e)
        {
            Cliente objCli = new Cliente();
            objCli.Nome = txtNome.Text;
            objCli.Cpf = txtCpf.Text;
            objCli.setNascimento(txtNascimento.Text);
           
            
            try
            {
                objCli.Validar();

                listCli.Add(objCli);

                Session["lista"] = listCli;

                CarregarListBox();//carregar listbox com list global
                CarregarListBox(listCli);//carregar listbox com list via parametro
                CarregarGrid();//carregar gridview com list global
                CarregarGrid(listCli);//carregar gridview com list via parametro
                CarregarListView();//carregar listview com list global
                CarregarListView(listCli);//carregar listview com list via parametro
                
            }
            catch (Exception ex)
            {
                lblAviso.Text = ex.Message;    
            }
        }
    }
}