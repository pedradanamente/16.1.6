﻿using Entidades;
using Negocio;
using System;
using System.Web.UI.WebControls;

namespace WebForms_G2
{
    public partial class frmCadastroProdutos : System.Web.UI.Page
    {
        private static string localUpload = "/imgs/";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
                CarregarGrid();
            
        }

        private void ResetForm()
        {
            
            txtNome.Text = "";
            txtQuantidade.Text = "";
            txtValor.Text = "";
            btnAtualizar.Enabled = false;
            btnCancelar.Enabled = false;
            btnSalvar.Enabled = true;
            chkAtivo.Checked = true;
            lblMensagem.Text = "";
            imgP.Visible = false;
            imgG.Visible = false;
            txtImgP.Text = "";
            txtImgG.Text = "";
            txtId.Text = "";
        }

        protected void btnSalvar_Click(object sender, EventArgs e)
        {
            try
            {
                Produto objProd = new Produto();
                objProd.Nome = txtNome.Text;
                objProd.Quantidade = Convert.ToInt16(txtQuantidade.Text);
                objProd.Valor = Convert.ToDecimal(txtValor.Text);
                objProd.Ativo = chkAtivo.Checked;
                if (fuImgGrande.HasFile)
                {
                    objProd.ImgG = localUpload + fuImgGrande.FileName;
                    Funcoes.UploadArquivos(fuImgGrande, Server.MapPath(localUpload));
                    //UploadArquivo(fuImgGrande);
                }
                if (fuImgPequena.HasFile)
                {
                    objProd.ImgP = localUpload + fuImgPequena.FileName;
                    Funcoes.UploadArquivos(fuImgPequena, Server.MapPath(localUpload));
                    //UploadArquivo(fuImgPequena);
                }
                if (new NGProduto().Salvar(objProd))
                {
                    lblMensagem.Text = "Registro inserido!";
                    ResetForm();
                    CarregarGrid();
                }
            }
            catch(Exception ex)
            {
                lblMensagem.Text = "Erro: " + ex.Message;
            }
        }

        private void CarregarGrid()
        {
            gvProdutos.DataSource = new NGProduto().Listar();
            gvProdutos.DataBind();
        }

        protected void gvProdutos_SelectedIndexChanged(object sender, EventArgs e)
        {
            int id = int.Parse(gvProdutos.SelectedRow.Cells[1].Text);
            try
            {
                Produto objProd = new NGProduto().Buscar(id);
                if (objProd != null)
                {
                    txtId.Text = objProd.Id.ToString();
                    txtNome.Text = objProd.Nome;
                    txtQuantidade.Text = objProd.Quantidade.ToString();
                    txtValor.Text = objProd.Valor.ToString();
                    chkAtivo.Checked = objProd.Ativo;
                    if (!string.IsNullOrEmpty(objProd.ImgP))
                    {
                        imgP.Visible = true;
                        imgP.ImageUrl = "~" + objProd.ImgP;
                        txtImgP.Text = objProd.ImgP;
                    }
                    if (!string.IsNullOrEmpty(objProd.ImgG))
                    {
                        imgG.Visible = true;
                        imgG.ImageUrl = "~" + objProd.ImgG;
                        txtImgG.Text = objProd.ImgG;
                    }
                    btnSalvar.Enabled = false;
                    btnAtualizar.Enabled = true;
                    btnCancelar.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                lblMensagem.Text = "Erro: " + ex.Message;
            }
        }

        protected void btnCancelar_Click(object sender, EventArgs e)
        {
            ResetForm();
        }

        protected void btnAtualizar_Click(object sender, EventArgs e)
        {
            try
            {
                Produto objProd = new Produto();
                objProd.Id = int.Parse(txtId.Text);
                objProd.Nome = txtNome.Text;
                objProd.Quantidade = int.Parse(txtQuantidade.Text);
                objProd.Valor = Convert.ToDecimal(txtValor.Text);
                objProd.Ativo = chkAtivo.Checked;
                if (fuImgGrande.HasFile)
                {
                    objProd.ImgG = localUpload + fuImgGrande.FileName;
                    Funcoes.UploadArquivos(fuImgGrande, Server.MapPath(localUpload));
                }
                else
                    objProd.ImgG = txtImgG.Text;

                if (fuImgPequena.HasFile)
                {
                    objProd.ImgP = localUpload + fuImgPequena.FileName;
                    Funcoes.UploadArquivos(fuImgPequena, Server.MapPath(localUpload));
                }
                else
                    objProd.ImgP = txtImgP.Text;

                if (new NGProduto().Atualizar(objProd))
                {
                    lblMensagem.Text = "Registro Atualizado!";
                    ResetForm();
                    CarregarGrid();
                }
            }
            catch (Exception ex)
            {
                lblMensagem.Text = "Erro: " + ex.Message;
            }
        }
    }
}