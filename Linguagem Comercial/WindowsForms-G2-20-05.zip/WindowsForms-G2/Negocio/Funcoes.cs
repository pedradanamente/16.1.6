﻿
namespace Negocio
{
    public class Funcoes
    {
        /// <summary>
        /// Metodo salvando um arquivo no servidor
        /// Foi referenciado o System.Web para esse projeto para verem um exemplo de passagem de parametro entre projetos com controles
        /// Contudo, poderia ser usado a passagem de parametro via byte[]
        /// </summary>
        /// <param name="fu">Componente com o arquivo anexado</param>
        /// <param name="path">Caminho relativo onde será salvo o arquivo</param>
        public static void UploadArquivos(System.Web.UI.WebControls.FileUpload fu, string path)
        {
            //verificar se existe a pasta
            if (!System.IO.File.Exists(path))
                System.IO.Directory.CreateDirectory(path);
            
            //pegar o nome do arquivo
            string fileName = fu.FileName;
            //concatenar local com arquivo para gerar um caminho completo
            path += fileName;
            //depois salvar
            fu.SaveAs(path);
        }
    }
}
