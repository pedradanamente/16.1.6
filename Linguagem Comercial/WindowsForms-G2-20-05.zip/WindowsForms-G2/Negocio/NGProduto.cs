﻿using Banco;
using Entidades;
using System.Collections.Generic;


namespace Negocio
{
    public class NGProduto
    {
        /// <summary>
        /// Salvar objeto produto no banco
        /// </summary>
        /// <param name="objeto"></param>
        /// <returns></returns>
        public bool Salvar(Produto objeto)
        {
            return new BDProduto().Salvar(objeto);
        }
        /// <summary>
        /// Atualizar registros do objeto produto
        /// </summary>
        /// <param name="objeto"></param>
        /// <returns></returns>
        public bool Atualizar(Produto objeto)
        {
            return new BDProduto().Atualizar(objeto);
        }

        /// <summary>
        /// Listar registros de objetos
        /// </summary>
        /// <returns></returns>
        public List<Produto> Listar()
        {
            return new BDProduto().Listar();
        }
        /// <summary>
        /// Buscar por um registro de objeto específico
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Produto Buscar(int id)
        {
            return new BDProduto().Buscar(id);
        }

    }
}
