﻿using Entidades;
using Negocio;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsForms_G2
{
    public partial class frmCadastroProduto : Form
    {
        int id;
        public frmCadastroProduto()
        {
            InitializeComponent();
            CarregarGrid();
        }

        private void ResetForm()
        {
            chkAtivo.Checked = true;
            txtImgG.Text = "";
            txtImgP.Text = "";
            txtNome.Text = "";
            txtQuantidade.Text = "";
            txtValor.Text = "";
            btnAtualizar.Enabled = false;
            btnSalvar.Enabled = true;
            btnCancelar.Enabled = false;
            picG.Image = null;
            picP.Image = null;
        }

        

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            try
            {
                Produto objProduto = new Produto();
                objProduto.Nome = txtNome.Text;
                objProduto.Quantidade = Convert.ToInt16(txtQuantidade.Text);
                objProduto.Valor = Convert.ToDecimal(txtValor.Text);
                objProduto.ImgP = txtImgP.Text;
                objProduto.ImgG = txtImgG.Text;
                objProduto.Ativo = chkAtivo.Checked;

                if (new NGProduto().Salvar(objProduto))
                {
                    ResetForm();
                    CarregarGrid();
                    MessageBox.Show("Registro inserido!");
                }
                else
                    MessageBox.Show("Erro ao inserir!");
            }
            catch(Exception ex)
            {
                MessageBox.Show("Erro: " + ex.Message);
            }
            
        }

        private void CarregarGrid()
        {
            dgvProdutos.AutoGenerateColumns = false;
            dgvProdutos.DataSource = new NGProduto().Listar();
            
            
        }

        private void dgvProdutos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            ResetForm();
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            try
            {
                Produto objProduto = new Produto();
                objProduto.Nome = txtNome.Text;
                objProduto.Quantidade = Convert.ToInt16(txtQuantidade.Text);
                objProduto.Valor = Convert.ToDecimal(txtValor.Text);
                objProduto.ImgP = txtImgP.Text;
                objProduto.ImgG = txtImgG.Text;
                objProduto.Ativo = chkAtivo.Checked;
                objProduto.Id = id;

                if (new NGProduto().Atualizar(objProduto))
                {
                    ResetForm();
                    CarregarGrid();
                    MessageBox.Show("Registro atualizado!");
                }
                else
                    MessageBox.Show("Erro ao inserir!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.Message);
            }

        }

        private void dgvProdutos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            id = int.Parse(dgvProdutos.Rows[e.RowIndex].Cells[0].Value.ToString());
            Produto objProd = new NGProduto().Buscar(id);
            if (objProd != null)
            {
                txtNome.Text = objProd.Nome;
                txtImgG.Text = objProd.ImgG;
                txtImgP.Text = objProd.ImgP;
                txtQuantidade.Text = objProd.Quantidade.ToString();
                txtValor.Text = objProd.Valor.ToString();
                chkAtivo.Checked = objProd.Ativo;
                picG.Image = null;
                picP.Image = null;
                picG.Image = Image.FromFile(objProd.ImgG);
                picP.Image = Image.FromFile(objProd.ImgP);
                btnAtualizar.Enabled = true;
                btnSalvar.Enabled = false;
                btnCancelar.Enabled = true;

            }
        }

    }
}
