﻿using Entidades;
using Negocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms_G2
{
    public partial class frmCadastroCliente : Form
    {
        int page = 1;
        int pageSize = 3;
        int id;

        public frmCadastroCliente()
        {
            InitializeComponent();
            CarregarGrid();
        }

        private void LimparForm()
        {
            txtNome.Text = "";
            txtCpf.Text = "";
            txtNome.Focus();
            btnAtualizar.Enabled = false;
            btnSalvar.Enabled = true;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            //instanciar a classe que será usada para manipular os dados inputados da tela
            //com o banco de dados
            Cliente objCliente = new Cliente();
            objCliente.Nome = txtNome.Text;//recebe as informações da tela
            objCliente.Cpf = txtCpf.Text;
            NGCliente objNG = new NGCliente();
            try
            {
                //valida, ao mesmo tempo que executa, se dados foram salvos no banco
                if (objNG.Salvar(objCliente))
                {
                    LimparForm();
                    CarregarGrid();
                    MessageBox.Show("Registro inserido");
                }
                else
                    MessageBox.Show("Não foi possível inserir o registro");
                
            }
            catch (Exception ex)
            {
                //se gerar exceção, receberá do catch da classe cliente
                MessageBox.Show("Erro: " + ex.Message);
            }
            
        }


        private void CarregarGrid()
        {
            //Cliente objCli = new Cliente();
            //List<Cliente> objListCli = objCli.Listar();
            //if (objListCli != null)
            //    dgvClientes.DataSource = objListCli;
            //else
            //    MessageBox.Show("Nenhum registro");
            NGCliente objNG = new NGCliente();
            dgvClientes.DataSource = objNG.Listar(page, pageSize);
            //dgvClientes.DataSource = new NGCliente().Listar();
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            page -= 1;
            if (page < 1)
                page = 1;
            CarregarGrid();
        }

        private void btnProx_Click(object sender, EventArgs e)
        {
            page += 1;
            CarregarGrid();
        }

        private void dgvClientes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            id = int.Parse(dgvClientes.Rows[e.RowIndex].Cells["Id"].Value.ToString());
            Cliente objCliente = new NGCliente().Buscar(id);
            if (objCliente != null)
            {
                txtNome.Text = objCliente.Nome;
                txtCpf.Text = objCliente.Cpf;
                btnAtualizar.Enabled = true;
                btnSalvar.Enabled = false;
            }
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            Cliente objCliente = new Cliente();
            objCliente.Nome = txtNome.Text;
            objCliente.Cpf = txtCpf.Text;
            objCliente.Id = id;
            try
            {
                if (new NGCliente().Atualizar(objCliente))
                {
                    LimparForm();
                    CarregarGrid();
                    MessageBox.Show("Registro atualizado");
                }
                else
                {
                    MessageBox.Show("Erro ao atualizar registro");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.Message);
            }
        }
    }
}
