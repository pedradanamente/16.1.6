﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banco
{
    public class BDBase
    {
        protected SqlConnection con;

        public BDBase()
        {
            this.con = Conexao.Conectar();
        }
    }
}
