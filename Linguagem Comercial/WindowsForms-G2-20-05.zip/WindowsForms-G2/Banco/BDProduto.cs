﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Banco
{
    public class BDProduto:BDBase
    {
        public bool Salvar(Produto objeto)
        {
            int ret = 0;

            string sql = "INSERT INTO produto (nome,quantidade,valor,imagem_p, imagem_g, ativo) values (@nome,@quantidade,@valor,@imagem_p, @imagem_g, @ativo)";
            SqlCommand cmd = new SqlCommand(sql, con);
            //adicionar parametro que é usado no comando sql
            cmd.Parameters.AddWithValue("@nome", objeto.Nome);
            cmd.Parameters.AddWithValue("@quantidade", objeto.Quantidade);
            cmd.Parameters.AddWithValue("@valor", objeto.Valor);
            cmd.Parameters.AddWithValue("@imagem_p", objeto.ImgP);
            cmd.Parameters.AddWithValue("@imagem_g", objeto.ImgG);
            cmd.Parameters.AddWithValue("@ativo", objeto.Ativo);
            try
            {
                //abrir conexão com banco
                con.Open();
                //executar comando e capturar nro de linhas afetadas
                ret = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                //"passar adiante" erro de exceção
                throw new Exception(ex.Message);
            }
            finally
            {
                //verificar se conexão está aberta...e se sim...fechar
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return ret > 0;
        }

        public bool Atualizar(Produto objeto)
        {
            int ret = 0;

            string sql = "UPDATE produto SET nome=@nome, quantidade=@quantidade, valor=@valor, imagem_p=@imagem_p, imagem_g=@imagem_g, ativo=@ativo where id=@id";
            SqlCommand cmd = new SqlCommand(sql, con);
            //adicionar parametro que é usado no comando sql
            cmd.Parameters.AddWithValue("@nome", objeto.Nome);
            cmd.Parameters.AddWithValue("@quantidade", objeto.Quantidade);
            cmd.Parameters.AddWithValue("@valor", objeto.Valor);
            cmd.Parameters.AddWithValue("@imagem_p", objeto.ImgP);
            cmd.Parameters.AddWithValue("@imagem_g", objeto.ImgG);
            cmd.Parameters.AddWithValue("@ativo", objeto.Ativo);
            cmd.Parameters.AddWithValue("@id", objeto.Id);
            try
            {
                //abrir conexão com banco
                con.Open();
                //executar comando e capturar nro de linhas afetadas
                ret = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                //"passar adiante" erro de exceção
                throw new Exception(ex.Message);
            }
            finally
            {
                //verificar se conexão está aberta...e se sim...fechar
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return ret > 0;
        }

        public List<Produto> Listar()
        {
            List<Produto> objList = null;
            Produto obj = null;

            string sql = "select * from produto order by nome";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr;
            try
            {
                con.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    objList = new List<Produto>();
                    while (dr.Read())
                    {
                        //instancio objeto cliente a cada item da lista de registos
                        obj = new Produto();
                        //leio as informações dos campos e jogo para o objeto
                        obj.Id = Convert.ToInt16(dr["id"]);
                        obj.Nome = dr["nome"].ToString();
                        obj.Ativo = Convert.ToBoolean(dr["ativo"]);
                        obj.ImgG = dr["imagem_p"].ToString();
                        obj.ImgP = dr["imagem_g"].ToString();
                        obj.Quantidade = Convert.ToInt16(dr["quantidade"]);
                        obj.Valor = Convert.ToDecimal(dr["valor"]);

                        objList.Add(obj);
                    }
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return objList;
        }

        public Produto Buscar(int id)
        {
            Produto obj = null;

            string sql = "select * from produto where id=@id";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@id", id);
            SqlDataReader dr;
            try
            {
                con.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    //posiociona o cursor no próximo registro (no caso o primeiro)
                    dr.Read();
                    //instancio objeto cliente a cada item da lista de registos
                    obj = new Produto();
                    //leio as informações dos campos e jogo para o objeto
                    obj.Id = Convert.ToInt16(dr["id"]);
                    obj.Nome = dr["nome"].ToString();
                    obj.Ativo = Convert.ToBoolean(dr["ativo"]);
                    obj.ImgG = dr["imagem_g"].ToString();
                    obj.ImgP = dr["imagem_p"].ToString();
                    obj.Quantidade = Convert.ToInt16(dr["quantidade"]);
                    obj.Valor = Convert.ToDecimal(dr["valor"]);


                }
                dr.Close();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return obj;
        }
    }
}
