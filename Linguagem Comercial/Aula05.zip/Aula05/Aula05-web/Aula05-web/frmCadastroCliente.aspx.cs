﻿using Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Aula05_web
{
    public partial class frmCadastroCliente : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSalvar_Click(object sender, EventArgs e)
        {
            Cliente objCli = new Cliente();
            objCli.Nome = txtNome.Text;
            objCli.Cpf = txtCpf.Text;
            objCli.setNascimento(txtNascimento.Text);

            try
            {
                objCli.Validar();

                
                lblNome.Text += " " + objCli.Nome;
                lblCpf.Text += " " + objCli.Cpf;
                lblNascimento.Text += " " + string.Format("{0:dd/MM/yyyy}", objCli.Nascimento());
            }
            catch (Exception ex)
            {
                lblAviso.Text = ex.Message;    
            }
        }
    }
}