﻿using Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aula05
{
    public partial class frmCadastroClientes : Form
    {
        public frmCadastroClientes()
        {
            InitializeComponent();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            //criar um novo objeto para alocar os dados que serão inputados no form
            Cliente objCli = new Cliente();
            objCli.Nome = txtNome.Text;
            objCli.Cpf = txtCpf.Text;
            objCli.setNascimento(txtNascimento.Text);

            //criar um arraylist do tipo cliente para alocar VÁRIOS clientes dentro
            List<Cliente> listCli = new List<Cliente>();

            try
            {
                //validar os dados
                //se gerar exceção, vai para o catch
                objCli.Validar();

                //adicionar objeto cliente no arraylist
                listCli.Add(objCli);

                //limpar os dados da label para exibí-los
                lblResultado.Text = "";

                //percorrer a lista de objetos clientes para pegar cada item dessa lista e manipular as informações
                foreach(Cliente item in listCli)
                {
                    lblResultado.Text += "Nome: " + item.Nome;
                    lblResultado.Text += "\nCpf: " + item.Cpf; //os caracters '\n' servem para inficar quebra de linha nas apps desktops
                    lblResultado.Text += "\nNascimento: " + item.Nascimento();
                    lblResultado.Text += "\n\n";
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        
    }
}
