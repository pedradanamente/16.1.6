-- --------------------------------------------------------
-- Servidor:                     localhost
-- Versão do servidor:           5.6.17-log - MySQL Community Server (GPL)
-- OS do Servidor:               Win32
-- HeidiSQL Versão:              9.2.0.4947
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Copiando estrutura do banco de dados para banco_de_dados_1
CREATE DATABASE IF NOT EXISTS `banco_de_dados_1` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `banco_de_dados_1`;


-- Copiando estrutura para tabela banco_de_dados_1.alunos
CREATE TABLE IF NOT EXISTS `alunos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) DEFAULT NULL,
  `dtanasc` date DEFAULT NULL,
  `sexo` enum('M','F') DEFAULT NULL,
  `trabalha` enum('Sim','Não') DEFAULT NULL,
  `cidade_natal` varchar(55) DEFAULT NULL,
  `semestre` int(1) DEFAULT NULL,
  `hobby` text,
  `time` varchar(25) DEFAULT NULL,
  `esporte` varchar(25) DEFAULT NULL,
  `banda` varchar(55) DEFAULT NULL,
  `cor` varchar(25) DEFAULT NULL,
  `comida` varchar(25) DEFAULT NULL,
  `site` varchar(55) DEFAULT NULL,
  `animal` varchar(25) DEFAULT NULL,
  `disciplina` varchar(55) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela banco_de_dados_1.alunos: ~24 rows (aproximadamente)
/*!40000 ALTER TABLE `alunos` DISABLE KEYS */;
INSERT INTO `alunos` (`id`, `nome`, `dtanasc`, `sexo`, `trabalha`, `cidade_natal`, `semestre`, `hobby`, `time`, `esporte`, `banda`, `cor`, `comida`, `site`, `animal`, `disciplina`) VALUES
	(1, 'Natalia Guidugli', '1995-10-01', 'F', 'Sim', 'Cachoeira do Sul', 3, 'Tocar Violão', 'Grêmio', 'Futebol', 'Legião Urbana', 'Preto', 'Pizza', NULL, 'Pássaro', NULL),
	(2, 'Lucas Ellwanger', '1994-05-03', 'M', 'Não', 'Cachoeira do Sul', 7, NULL, 'Grêmio', 'Basquete', NULL, 'Laranja', 'Sushi', NULL, 'Leão', 'Banco de Dados I'),
	(3, 'Juliano Leites', '1985-06-28', 'M', 'Sim', 'Cachoeira do Sul', 5, 'Praticar Esportes', 'Internacional', 'Futebol', 'Bob Marley', 'Vermelho', 'Churrasco', 'youtube', 'Cachorro', 'Lógica de Predicados'),
	(4, 'Renato Moraes', '1987-10-10', 'M', 'Sim', 'Cachoeira do Sul', 3, NULL, 'Grêmio', NULL, 'Capital Inicial', 'Preto', 'Churrasco', NULL, 'Cachorro', NULL),
	(5, 'Gíulia Bordignon', '1995-09-16', NULL, 'Sim', 'Cachoeira do Sul', 5, 'Leitura', NULL, 'Ciclismo', NULL, NULL, NULL, 'Escreva Lola, Escreva', 'Camaleão', 'Algoritmos'),
	(6, 'Leonardo Giuliani', '1997-03-05', 'M', 'Não', 'Cachoeira do Sul', 3, 'Futebol e Videogame', 'Grêmio', 'Futebol', 'Coldplay', 'Azul', 'Pizza', 'Wikipedia', 'Cachorro', 'Algoritmos'),
	(7, 'Carlos Roberto', '1993-09-07', 'M', 'Sim', 'Cachoeira do Sul', 9, 'Filmes', 'Grêmio', NULL, NULL, 'Azul', 'Churrasco', 'Google', 'Gavião', 'Qualidade de Software'),
	(8, 'Lucas Machado', '1989-10-05', 'M', 'Sim', 'Porto Alegre', 4, 'Videogame', 'Grêmio', 'Vôlei', 'Linkin Park', 'Preto', 'Massa', 'Techmundo', NULL, 'Fundamentos Profissionais'),
	(9, 'Daniel Cazarotto', '1993-08-28', 'M', 'Sim', 'Cachoeira do Sul', 7, NULL, 'Grêmio', 'Futebol', NULL, 'Azul', 'Lasanha', 'Facebook', 'Leão', NULL),
	(10, 'José Carlos', '1992-07-05', 'M', 'Sim', 'Cachoeira do Sul', 4, 'Dormir', 'Grêmio', 'Futebol', 'AC/DC', 'Azul', 'Churrasco', 'Twitter', NULL, NULL),
	(11, 'Henrique Zillmann', '1995-03-31', 'M', 'Sim', 'Porto Alegre', 5, 'Dar rolé', 'Grêmio', 'Futebol', NULL, 'Azul', 'Lasanha', 'Globo Esporte', 'Leão', NULL),
	(12, 'Elton Elesbão', '1990-05-22', 'M', 'Não', 'Formoso do Araguaia', 3, 'Colecionar Filmes', 'Grêmio', 'Futebol', NULL, 'Azul', 'Massa', 'Rádio Gaúcha', 'Águia', 'Banco de Dados I'),
	(13, 'Julia Crumenauer', '1996-11-18', 'F', 'Não', 'Cachoeira do Sul', 3, 'Jogar e Assistir Séries e Filmes', NULL, NULL, NULL, 'Laranja', 'Lasanha', 'Youtube', NULL, NULL),
	(14, 'Giovani Corrêa', '1993-12-15', 'M', 'Não', 'Cachoeira do Sul', 7, 'Fazer nada', 'Grêmio', 'Tênis', NULL, 'Vermelho', 'Lasanha', 'Youtube', 'Puma', 'Atividades Complementares'),
	(15, 'Evandro Ellwanger', '1989-08-23', 'M', 'Sim', 'Cachoeira do Sul', 4, NULL, 'Grêmio', 'Futebol', NULL, 'Azul', 'Churrasco', NULL, NULL, 'Redes de Computadores I'),
	(16, 'Guilherme Rossato', '1984-07-29', 'M', 'Sim', 'Cachoeira do Sul', 3, 'Academia', 'Grêmio', 'Basquete', 'Iron Maiden', 'Azul', 'Churrasco', 'Techmundo', 'Gavião', 'Algoritmos'),
	(17, 'Ricardo Moraes', '2015-08-27', 'M', 'Sim', 'Cachoeira do Sul', 4, NULL, 'Grêmio', NULL, NULL, 'Azul', 'Churrasco', NULL, NULL, 'Fundamentos Profissionais'),
	(18, 'Francisco Choaire', '1985-11-07', 'M', 'Sim', 'Cachoeira do Sul', 8, 'Passear de Moto', 'Grêmio', 'MMA', 'Totalmente Eclético', 'Azul', 'Churrasco', 'Facebook', 'Ave', 'Inteligência Artificial'),
	(19, 'André Machado', '1990-05-08', 'M', 'Sim', 'Cachoeira do Sul', 3, 'Ouvir Música', NULL, NULL, 'Ace Frehley', 'Preto', 'Polar', 'puntel.org', 'Animal', 'Redes de Computadores'),
	(20, 'Cristian Silveira', '1994-10-17', 'M', 'Não', 'Cachoeira do Sul', 3, 'Jogar no Computador', 'Internacional', 'BMX', 'The Strokes', 'Preto', 'Pizza', 'Regeddit', 'Pássaro', NULL),
	(21, 'Lucas Florence', '1989-05-10', 'M', 'Sim', 'Porto Alegre', 3, 'Eletrôniac', 'Grêmio', NULL, NULL, 'Preto', NULL, 'Soundcloud', NULL, 'Linguagem de Programação Web'),
	(22, 'Nauber Brandão', '1980-05-10', 'M', 'Não', 'Porto Alegre', 5, 'Tocar Violão', 'Internacional', NULL, 'The Doors', 'Preto', 'Pizza', 'Youtube', 'Cachorro', NULL),
	(23, 'Isabelle Tatsch', '1996-08-20', 'F', 'Não', 'Cachoeira do Sul', 3, 'Jogos e Seriados', NULL, 'Sedentarismo', NULL, 'Vermelho', 'Strogonoff', NULL, 'Ovelha', NULL),
	(24, 'José Renato', '1978-11-13', 'M', 'Sim', 'Cachoeira do Sul', 7, NULL, 'Grêmio', 'Futebol', NULL, 'Azul', NULL, NULL, NULL, NULL);
/*!40000 ALTER TABLE `alunos` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
