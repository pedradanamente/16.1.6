﻿CREATE DATABASE IF NOT EXISTS `bd1` DEFAULT CHARACTER SET latin1;
USE `bd1`;

CREATE TABLE IF NOT EXISTS `alunos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) DEFAULT NULL,
  `dtanasc` date DEFAULT NULL,
  `sexo` char(1) DEFAULT NULL,
  `trabalha` char(3) DEFAULT NULL,
  `cidade_natal` varchar(55) DEFAULT NULL,
  `semestre` int(1) DEFAULT NULL,
  `hobby` text,
  `time` varchar(25) DEFAULT NULL,
  `esporte` varchar(25) DEFAULT NULL,
  `banda` varchar(55) DEFAULT NULL,
  `cor` varchar(25) DEFAULT NULL,
  `comida` varchar(25) DEFAULT NULL,
  `site` varchar(55) DEFAULT NULL,
  `animal` varchar(25) DEFAULT NULL,
  `disciplina` varchar(55) DEFAULT NULL,
  PRIMARY KEY (`id`)
) AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

INSERT INTO `alunos` (`id`, `nome`, `dtanasc`, `sexo`, `trabalha`, `cidade_natal`, `semestre`, `hobby`, `time`, `esporte`, `banda`, `cor`, `comida`, `site`, `animal`, `disciplina`) VALUES
	(1, 'Natalia Guidugli', '1995-10-01', 'F', 'Sim', 'Cachoeira do Sul', 3, 'Tocar Violão', 'Grêmio', 'Futebol', 'Legião Urbana', 'Preto', 'Pizza', NULL, 'Pássaro', NULL),
	(2, 'Lucas Ellwanger', '1994-05-03', 'M', '', 'Cachoeira do Sul', 7, NULL, 'Grêmio', 'Basquete', NULL, 'Laranja', 'Sushi', NULL, 'Leão', 'Banco de Dados I'),
	(3, 'Juliano Leites', '1985-06-28', 'M', 'Sim', 'Cachoeira do Sul', 5, 'Praticar Esportes', 'Internacional', 'Futebol', 'Bob Marley', 'Vermelho', 'Churrasco', 'YouTube', 'Cachorro', 'Lógica de Predicados'),
	(4, 'Renato Moraes', '1987-10-10', 'M', 'Sim', 'Cachoeira do Sul', 3, NULL, 'Grêmio', NULL, 'Capital Inicial', 'Preto', 'Churrasco', NULL, 'Cachorro', NULL),
	(5, 'Gíulia Bordignon', '1995-09-16', NULL, 'Sim', 'Cachoeira do Sul', 5, 'Leitura', NULL, 'Ciclismo', NULL, NULL, NULL, 'Escreva Lola, Escreva', 'Camaleão', 'Algoritmos'),
	(6, 'Leonardo Giuliani', '1997-03-05', 'M', 'Não', 'Cachoeira do Sul', 3, 'Futebol e Videogame', 'Grêmio', 'Futebol', 'Coldplay', 'Azul', 'Pizza', 'Wikipedia', 'Cachorro', 'Algoritmos'),
	(7, 'Carlos Roberto', '1993-09-07', 'M', 'Sim', 'Cachoeira do Sul', 9, 'Filmes', 'Grêmio', NULL, NULL, 'Azul', 'Churrasco', 'Google', 'Gavião', 'Qualidade de Software'),
	(8, 'Lucas Machado', '1989-10-05', 'M', 'Sim', 'Porto Alegre', 4, 'Videogame', 'Grêmio', 'Vôlei', 'Linkin Park', 'Preto', 'Massa', 'Techmundo', NULL, 'Fundamentos Profissionais'),
	(9, 'Daniel Cazarotto', '1993-08-28', 'M', 'Sim', 'Cachoeira do Sul', 7, NULL, 'Grêmio', 'Futebol', NULL, 'Azul', 'Lasanha', 'Facebook', 'Leão', NULL),
	(10, 'José Carlos', '1992-07-05', 'M', 'Sim', 'Cachoeira do Sul', 4, 'Dormir', 'Grêmio', 'Futebol', 'AC/DC', 'Azul', 'Churrasco', 'Twitter', NULL, NULL),
	(11, 'Henrique Zillmann', '1995-03-31', 'M', 'Sim', 'Porto Alegre', 5, 'Dar rolé', 'Grêmio', 'Futebol', NULL, 'Azul', 'Lasanha', 'Globo Esporte', 'Leão', NULL),
	(12, 'Elton Elesbão', '1990-05-22', 'M', '', 'Formoso do Araguaia', 3, 'Colecionar Filmes', 'Grêmio', 'Futebol', NULL, 'Azul', 'Massa', 'Rádio Gaúcha', 'Águia', 'Banco de Dados I'),
	(13, 'Julia Crumenauer', '1996-11-18', 'F', 'Não', 'Cachoeira do Sul', 3, 'Jogar e Assistir Séries e Filmes', NULL, NULL, NULL, 'Laranja', 'Lasanha', 'YouTube', NULL, NULL),
	(14, 'Giovani Corrêa', '1993-12-15', 'M', 'Não', 'Cachoeira do Sul', 7, 'Fazer nada', 'Grêmio', 'Tênis', NULL, 'Vermelho', 'Lasanha', 'YouTube', 'Puma', 'Atividades Complementares'),
	(15, 'Evandro Ellwanger', '1989-08-23', 'M', 'Sim', 'Cachoeira do Sul', 4, NULL, 'Grêmio', 'Futebol', NULL, 'Azul', 'Churrasco', NULL, NULL, 'Redes de Computadores I'),
	(16, 'Guilherme Rossato', '1984-07-29', 'M', 'Sim', 'Cachoeira do Sul', 3, 'Academia', 'Grêmio', 'Basquete', 'Iron Maiden', 'Azul', 'Churrasco', 'Techmundo', 'Gavião', 'Algoritmos'),
	(17, 'Ricardo Moraes', '1925-08-27', 'M', 'Sim', 'Cachoeira do Sul', 4, NULL, 'Grêmio', NULL, NULL, 'Azul', 'Churrasco', NULL, NULL, 'Fundamentos Profissionais'),
	(18, 'Francisco Choaire', '1985-11-07', 'M', 'Sim', 'Cachoeira do Sul', 8, 'Passear de Moto', 'Grêmio', 'MMA', 'Totalmente Eclético', 'Azul', 'Churrasco', 'Facebook', 'Ave', 'Inteligência Artificial'),
	(19, 'André Machado', '1990-05-08', 'M', 'Sim', 'Cachoeira do Sul', 3, 'Ouvir Música', NULL, NULL, 'Ace Frehley', 'Preto', 'Polar', 'puntel.org', 'Animal', 'Redes de Computadores'),
	(20, 'Cristian Silveira', '1994-10-17', 'M', 'Não', 'Cachoeira do Sul', 3, 'Jogar no Computador', 'Internacional', 'BMX', 'The Strokes', 'Preto', 'Pizza', 'Regeddit', 'Pássaro', NULL),
	(21, 'Lucas Florence', '1989-05-10', 'M', 'Sim', 'Porto Alegre', 3, 'Eletrônica', 'Grêmio', NULL, NULL, 'Preto', NULL, 'Soundcloud', NULL, 'Linguagem de Programação Web'),
	(22, 'Nauber Brandão', '1980-05-10', 'M', '', 'Porto Alegre', 5, 'Tocar Violão', 'Internacional', NULL, 'The Doors', 'Preto', 'Pizza', 'YouTube', 'Cachorro', NULL),
	(23, 'Isabelle Tatsch', '1996-08-20', 'F', 'Não', 'Cachoeira do Sul', 3, 'Jogos e Seriados', NULL, 'Sedentarismo', NULL, 'Vermelho', 'Strogonoff', NULL, 'Ovelha', NULL),
	(24, 'José Renato', '1978-11-13', 'M', 'Sim', 'Cachoeira do Sul', 7, NULL, 'Grêmio', 'Futebol', NULL, 'Azul', NULL, NULL, NULL, NULL);


CREATE TABLE IF NOT EXISTS `pedido` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aluno_id` int(10) unsigned NOT NULL,
  `dta` date NOT NULL,
  `total` float(7,2) NOT NULL,
  PRIMARY KEY (`id`)
) AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `pedido` (`id`, `aluno_id`, `dta`, `total`) VALUES
	(1, 10, '2015-06-12', 90.00),
	(2, 11, '2015-06-14', 1050.00),
	(3, 12, '2015-06-19', 570.00),
	(4, 18, '2015-06-16', 0.00);


CREATE TABLE IF NOT EXISTS `produto` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `categoria` varchar(55) NOT NULL,
  `valorun` float(7,2) NOT NULL,
  `estoque` int(10) unsigned NOT NULL,
  `dtains` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `produto` (`id`, `nome`, `categoria`, `valorun`, `estoque`, `dtains`) VALUES
	(1, 'Livro Banco de Dados I', 'Livros', 20.00, 35, '2015-06-16 11:03:40'),
	(2, 'Livro Sistemas de Informação', 'Livros', 90.00, 27, '2015-06-16 11:03:41'),
	(3, 'Tablet', 'Eletrônicos', 450.00, 12, '2015-06-16 11:03:43'),
	(4, 'HD Externo', 'Eletrônicos', 200.00, 7, '2015-06-16 11:03:44'),
	(5, 'Livro Engenharia de Software', 'Livros', 50.00, 19, '2015-06-16 11:03:51'),
	(6, 'iPhone', 'Eletrônicos', 1990.00, 4, '2015-06-16 11:03:52'),
	(7, 'Livro Segurança de Sistemas', 'Livros', 99.00, 13, '2015-06-16 11:03:52'),
	(8, 'Linkedin Park', 'DVD', 29.90, 5, '2015-06-16 11:03:53'),
	(9, 'Galinha Pintadinha', 'DVD', 9.90, 24, '2015-06-16 11:03:55');


CREATE TABLE IF NOT EXISTS `pedido_produto` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pedido_id` int(10) unsigned NOT NULL,
  `produto_id` int(10) unsigned NOT NULL,
  `qtd` int(10) unsigned NOT NULL,
  `valorun` float(5,2) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `pedido_produto` (`id`, `pedido_id`, `produto_id`, `qtd`, `valorun`) VALUES
	(1, 1, 1, 2, 20.00),
	(2, 1, 5, 1, 50.00),
	(3, 2, 4, 3, 200.00),
	(4, 2, 3, 1, 450.00),
	(6, 3, 2, 5, 90.00),
	(7, 3, 1, 1, 20.00),
	(8, 3, 5, 2, 50.00);
