CREATE DATABASE locadora;

USE locadora;

CREATE TABLE atores (
  id INTEGER UNSIGNED  NOT NULL   AUTO_INCREMENT,
  nome VARCHAR(55) NOT NULL  ,
  sobrenome VARCHAR(55) NOT NULL  ,
  dtanasc DATE  NULL  ,
  biografia TEXT  NULL    ,
PRIMARY KEY(id));



CREATE TABLE cliente (
  id INTEGER UNSIGNED  NOT NULL   AUTO_INCREMENT,
  cpf CHAR(14) NOT NULL  ,
  nome VARCHAR(255) NOT NULL  ,
  dtanasc DATE  NULL  ,
  fone VARCHAR(15) NOT NULL  ,
  celular VARCHAR(15)  NULL    ,
PRIMARY KEY(id));



CREATE TABLE fornecedor (
  id INTEGER UNSIGNED  NOT NULL   AUTO_INCREMENT,
  nome VARCHAR(255) NOT NULL  ,
  logradouro VARCHAR(255)  NULL  ,
  numero VARCHAR(15)  NULL  ,
  bairro VARCHAR(15)  NULL  ,
  cidade VARCHAR(25)  NULL  ,
  uf CHAR(2)  NULL  ,
  fone1 VARCHAR(15) NOT NULL  ,
  fone2 VARCHAR(15) NULL    ,
PRIMARY KEY(id));



CREATE TABLE aluguel (
  id INTEGER UNSIGNED  NOT NULL   AUTO_INCREMENT,
  cliente_id INTEGER UNSIGNED  NOT NULL  ,
  dtalocacao DATE NOT NULL  ,
  dtadevolucao DATE NOT NULL  ,
  valortotal FLOAT(5,2) NOT NULL    ,
PRIMARY KEY(id),
  FOREIGN KEY(cliente_id)
    REFERENCES cliente(id)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION);



CREATE TABLE filme (
  id INTEGER UNSIGNED  NOT NULL   AUTO_INCREMENT,
  fornecedor_id INTEGER UNSIGNED  NOT NULL  ,
  titulo VARCHAR(255) NOT NULL  ,
  pais VARCHAR(15) NOT NULL  ,
  dtacriacao DATE NOT NULL  ,
  qtd INTEGER UNSIGNED NOT NULL  ,
  valor FLOAT(4,2) NOT NULL    ,
PRIMARY KEY(id),
  FOREIGN KEY(fornecedor_id)
    REFERENCES fornecedor(id)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION);



CREATE TABLE aluguel_filmes (
  id INTEGER UNSIGNED  NOT NULL   AUTO_INCREMENT,
  aluguel_id INTEGER UNSIGNED  NOT NULL  ,
  filme_id INTEGER UNSIGNED  NOT NULL    ,
PRIMARY KEY(id),
  FOREIGN KEY(filme_id)
    REFERENCES filme(id)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION,
  FOREIGN KEY(aluguel_id)
    REFERENCES aluguel(id)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION);



CREATE TABLE atores_filmes (
  atores_id INTEGER UNSIGNED  NOT NULL  ,
  filme_id INTEGER UNSIGNED  NOT NULL  ,
  tipo ENUM('Principal','Coadjuvante') NOT NULL    ,
PRIMARY KEY(atores_id, filme_id),
  FOREIGN KEY(atores_id)
    REFERENCES atores(id)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION,
  FOREIGN KEY(filme_id)
    REFERENCES filme(id)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION);



