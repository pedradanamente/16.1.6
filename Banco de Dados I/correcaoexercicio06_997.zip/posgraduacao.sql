CREATE DATABASE posgraduacao;

USE posgraduacao;

CREATE TABLE orientador (
  id INTEGER UNSIGNED  NOT NULL   AUTO_INCREMENT,
  nome VARCHAR(255) NOT NULL  ,
  dtanasc DATE NOT NULL    ,
PRIMARY KEY(id));



CREATE TABLE candidato (
  id INTEGER UNSIGNED  NOT NULL   AUTO_INCREMENT,
  nome VARCHAR(255)  NOT NULL  ,
  logradouro VARCHAR(255)  NULL  ,
  numero VARCHAR(55)  NULL  ,
  bairro VARCHAR(55)  NULL  ,
  cep CHAR(9)  NULL  ,
  cidade VARCHAR(255)  NULL  ,
  uf CHAR(2)  NULL  ,
  plano TEXT  NULL    ,
PRIMARY KEY(id));



CREATE TABLE nota (
  id INTEGER UNSIGNED  NOT NULL   AUTO_INCREMENT,
  candidato_id INTEGER UNSIGNED  NOT NULL  ,
  ano INT(2) UNSIGNED  NOT NULL  ,
  nota FLOAT(5,2)  NOT NULL    ,
PRIMARY KEY(id),
  FOREIGN KEY(candidato_id)
    REFERENCES candidato(id)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION);



CREATE TABLE candidato_orientador (
  candidato_id INTEGER UNSIGNED  NOT NULL  ,
  orientador_id INTEGER UNSIGNED  NOT NULL  ,
  situacao ENUM('Aprovado','Reprovado','Em Andamento') NOT NULL    ,
PRIMARY KEY(candidato_id, orientador_id),
  FOREIGN KEY(candidato_id)
    REFERENCES candidato(id)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION,
  FOREIGN KEY(orientador_id)
    REFERENCES orientador(id)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION);



