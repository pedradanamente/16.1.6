<?
	class Classe2 extends Classe1{ 
		function bomDia(){ 
			Classe1::bomDia(); //Exibe 
			print "Classe2 {$this->var1} <br/>"; //N�o exibe nada
			print "Classe2 {$this->var2} <br/>"; //Exibe 
			print "Classe2 {$this->var3} <br/>"; //Exibe 
		}
	} 
?>