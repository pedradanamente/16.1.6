﻿<?
	class Classe1{ 
		private $var1 = "Olá, var1! \n"; 
		protected $var2 = "Olá, var2! \n"; 
		protected $var3 = "Olá, var3! \n"; 

		function bomDia(){ 
			print "Classe1 {$this->var1} <br/>"; 
			print "Classe1 {$this->var2} <br/>"; 
			print "Classe1 {$this->var3} <br/><br/>"; 
		} 
	}
?>