﻿<?
	function __autoload($class_name) {
		require_once("includes/class/class.{$class_name}.php");
	}
?>