<?
	include('config.php');
?>

<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<title>PHP OO</title>
	</head>
	<body>
		<?
			$estoque = new Loja();
			echo "Tenho {$estoque->itens['bermudas']} bermudas. <br/>";

			$estoque->adiciona('bermudas',2);
			echo "Tenho {$estoque->itens['bermudas']} bermudas. <br/>";

			$estoque->adiciona('cal�as',8);
			echo "Tenho {$estoque->itens['cal�as']} cal�as. <br/>";

			$estoque->remove('cal�as',3);
			echo "Tenho {$estoque->itens['cal�as']} cal�as. <br/>";

			$obj = new Classe1();
			$obj->bomDia();

			$obj2 = new Classe2();
			$obj2->bomDia();
		?>
	</body>
</html>


