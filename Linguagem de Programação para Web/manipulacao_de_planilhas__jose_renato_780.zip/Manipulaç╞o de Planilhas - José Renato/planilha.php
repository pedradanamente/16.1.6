﻿<!DOCTYPE html>
<html lang="pt-br">
        <head>
                <title>Meu primeiro site PHP</title>
                <link rel="stylesheet" type="text/css" href="style.css" />
				
                
        </head>
        <body>
                <div id="pagina">
                        <div id="topo">
                                <a href="testando.php"><img src="php.png" alt="" width="200" border="0" /></a>
                        </div>
                        <div id="menu">
                                <ul>
                                        
                                        <li>
                                                <a href="planilha.php">Gerar Planilha</a>
                                        </li>
										
										<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
                                        
                                </ul>
                        </div>
                        <div id="conteudo">
	    <fieldset>
			
		 <form action="importar.php" method="POST">	
         <input type="text" name="codigo" value="Código"><input type="text" name="nome" value="Nome"><input type="text" name="idade" value="Idade">
         <br/>
         <input type="text" name="codigo1" value=""><input type="text" name="nome1" value=""><input type="text" name="idade1" value="">
         <br/>
         <input type="text" name="codigo2" value=""><input type="text" name="nome2" value=""><input type="text" name="idade2" value="">
         <br/>
         <input type="text" name="codigo3" value=""><input type="text" name="nome3" value=""><input type="text" name="idade3" value="">
		  <br/>
		  <br/>
         <input type="submit" name="envia">
	     </form>
		</fieldset>
		 
		<p>
		
				
			</p>
		
                        </div>
                        <div id="rodape">Desenvolvido na disciplina de LPWEB &copy; 2014</div>
                </div>
        </body>
</html>