﻿<?php
	
	
	
	$arquivo = 'planilha.xls';//definição do nome do arquivo que será gerado
	 
	// tabela html com formato de planilha
	$html = '';
	$html .= '<table>';
	$html .= '<tr>';
	$html .= "<td><b>{$_POST["codigo"]}</b></td>";
	$html .= "<td><b>{$_POST["nome"]}</b></td>";
	$html .= "<td><b>{$_POST["idade"]}</b></td>";
    $html .= '<tr>';
	$html .= "<td>{$_POST["codigo1"]}</td>";
	$html .= "<td>{$_POST["nome1"]}</td>";
	$html .= "<td>{$_POST["idade1"]}</td>";
	$html .= '</tr>';
	$html .= '<tr>';
	$html .= "<td>{$_POST["codigo2"]}</td>";
	$html .= "<td>{$_POST["nome2"]}</td>";
	$html .= "<td>{$_POST["idade2"]}</td>";
	$html .= '</tr>';
	$html .= '<tr>';
	$html .= "<td>{$_POST["codigo3"]}</td>";
	$html .= "<td>{$_POST["nome3"]}</td>";
	$html .= "<td>{$_POST["idade3"]}</td>";
	$html .= '</tr>';
	$html .= '</table>';
	 
	// Códigos para gerar download
	header ("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
	header ("Last-Modified: " . gmdate("D,d M YH:i:s") . " GMT");
	header ("Cache-Control: no-cache, must-revalidate");
	header ("Pragma: no-cache");
	header ("Content-type: application/x-msexcel");
	header ("Content-Disposition: attachment; filename=\"{$arquivo}\"" );
	header ("Content-Description: PHP Generated Data" );	 
	
	echo $html;//envia o conteudo para download
	
	 
	?>

