﻿<h2>Formulário de contato</h2>

<form>
	Nome <input type="text" name="nome" /> <br/>
	Mensagem <textarea></textarea>
	<input type="submit" name="enviar" value="Enviar" /> <br/> <br/>
</form>