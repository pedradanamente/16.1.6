﻿<!DOCTYPE html>
<html>
	<head>
		<link href="dist/css/bootstrap.min.css" rel="stylesheet">

		<title>Ultimas noticias G1</title>
	</head>
	<body>
		<nav class="navbar navbar-fixed-top navbar-inverse" role="navigation">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
					</button>
				<a class="navbar-brand" href="#">Project name</a>
				</div>
				<div id="navbar" class="collapse navbar-collapse">
					<ul class="nav navbar-nav">
						<li class="active"><a href="#">Home</a></li>
					</ul>
				</div>
			</div>
		</nav>
		
		<div class="container">
			<div class="row row-offcanvas row-offcanvas-right">
				<div class="col-xs-12 col-sm-9">
					<p class="pull-right visible-xs">
						<button type="button" class="btn btn-primary btn-xs" data-toggle="offcanvas">Toggle nav</button>
					</p>
					<div class="jumbotron">
						<h1>Notícias G1!</h1>
						<p>Aqui é mostrado as últimas notícias da g1.globo.com.<br/>Este é um trabalho extra classe de Linguagem de Programação Web.</p>
					</div>
					<div class="row">
					<?php
						$contador = 0;
						foreach(globo_ler_noticias() as $artigo)
						{
							$contador++;?>
						<div class="col-xs-6 col-lg-4" id="<?php echo $contador ?>">
							<h2><?php echo $artigo['title']?></h2>
							<p><?php echo $artigo['description']?></p>
							<p><a class="btn btn-default" href="<?php echo $artigo['link']?>" role="button">View details &raquo;</a></p>
						</div>
						<?php
						}
						?>
					</div>
				</div>
				<div class="col-xs-6 col-sm-3 sidebar-offcanvas" id="sidebar" role="navigation">
					<div class="list-group">
						
						<?php
						$contador = 0;
						foreach(globo_ler_noticias() as $artigo)
						{
							$contador++;
						?>
						<a href="#<?php echo $contador?>" class="list-group-item active"><?php echo substr ($artigo['title'], 0, 20) ."..."?></a>
						<?php
						}
						?>
					</div>
				</div>
			</div>
		</div>
		<?php
		function globo_ler_noticias(){
		//http://g1.globo.com/dynamo/rss2.xml
			$feed = file_get_contents('http://g1.globo.com/dynamo/rss2.xml');
			$feed = simplexml_load_string($feed);
			//print_r($feed); 
			
			$artigos = array();
			
			foreach ($feed->channel->item as $item)
			{
				$artigos[] = array
				(
					'title' 		=> (string)$item->title,
					'description'	=> (string)$item->description,
					'link'			=> (string)$item->link,
					'pubDate'		=> (string)$item->pubDate,
				);
			}
			
			return($artigos);;
		}
		?>
	</body>
</html>



