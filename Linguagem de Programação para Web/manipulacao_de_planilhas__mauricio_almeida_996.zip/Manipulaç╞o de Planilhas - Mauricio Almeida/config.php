﻿<?
$servidor="localhost";$login="root";$senha="123";$base="aula";
@$conecta=mysql_connect($servidor,$login,$senha) or die ('Erro: '.mysql_error());
mysql_select_db($base,$conecta) or die ('Erro: '.mysql_error());
?>