﻿<!DOCTYPE html>

<html lang="pt-BR">
	<head>
	<title> Atividade 2</title>
	</head>
		<body>
<form action="processa.php" method="POST">
	<b>CDS</b> 
	<p/>Código: <input type="text" name="idCd" size="11"></p>
	<p/>Nome do CD: <input type="text" name="nomeCd" size="50"></p> 
	<p/>Em Estoque: <input type="text" name="emStock" size="10"></p> 
	<p/>Em Encomenda: <input type="text" name="emEncomenda" size="10"></p> 
	<p/>Em Reserva: <input type="text" name="emReserva" size="10"></p>
				<legend>Gênero:
				<input type="radio" name="Genero" id="Classical" value="Clássico" />
				<label for="Genero">Clássico</label>
				<input type="radio" name="Genero" id="Popular" value="Popular" />
				<label for="Genero">Popular</label>
				</legend>
	<p/>Categoria: <input type="text" name="Categoria" size="20"></p> 	 	
	
	
	
	<p><input type="submit" value="Enviar" name="enviar"></p> 
</form> 

	</body>
</html>

	