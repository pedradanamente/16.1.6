﻿<?php
// CONECTA COM O BANCO
include("config.php");

// SELECIONA O BANCO DE DADOS
$SQL = "SELECT * FROM CDs" ;


// DEFINE O FORMATO MS EXCEL
header("Content-type: application/vdn.ms.excel");

// DEFINE O NOME DO ARQUIVO A SALVAR
header("Content-Disposition: attachment; filename=cds.xls");

// CRIA UMA TABELA QUE VAI RECEBER OS DADOS DO BANCO
echo "<table>";
 echo "<tr>";
	echo "<td></td>";
	echo "<td>Código</td>";
	echo "<td>Nome do CD</td>";
	echo "<td>Em Estoque</td>";
	echo "<td>Em Encomenda</td>";
	echo "<td>Em Reserva</td>";
	echo "<td>Gênero</td>";
	echo "<td>Categoria</td>";
 echo "</tr>";

//VARIÁVEL QUE ENVIA CONSULTA AO BANCO DE DADOS
$consulta = mysql_query($SQL);
$x=1;
//LAÇO QUE RETORNA O RESULTADO DA LINHA CONSULTADA
while ($r = mysql_fetch_array($consulta)){
 echo "<tr>";
	echo "<td>".$x."</td>";
	echo "<td>" . $r["idCd"] . "</td>";
	echo "<td>" . $r["nomeCd"] . "</td>";
	echo "<td>" . $r["emStock"] . "</td>";
	echo "<td>" . $r["emEncomenda"] . "</td>";
	echo "<td>" . $r["emReserva"] . "</td>";
	echo "<td>" . $r["Genero"] . "</td>";
	echo "<td>" . $r["Categoria"] . "</td>";
 echo "</tr>";
 $x++;
}
echo "</table>"; 
?>