﻿<?
	include ('config.php');
?>

<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<title>Meu primeiro site PHP</title>
		<link rel="stylesheet" type="text/css" href="style.css" />

	</head>
	<body>
		<div id="pagina">
			<div id="topo">
				<a href="index.php"><img src="php.png" alt="" width="200" border="0" /></a>
			</div>
			<div id="menu">
				<ul>
					<li>
						<a href="index.php">Início</a>
					</li>
					<li>
						<a href="index.php?pagina=lista">LISTAR</a>
					</li>
					<li>
						<a href="index.php?pagina=cadastro">CADASTRAR</a>
					</li>
					<li>
						<a href="index.php?pagina=altera">ALTERAR</a>
					</li>
					<li>
						<a href="index.php?pagina=deleta">DELETAR</a>
					</li>
				</ul>
			</div>
			<div id="conteudo">
			<?
				if(!empty($_GET['pagina']) && file_exists("inc_{$_GET['pagina']}.php"))
					include("inc_{$_GET['pagina']}.php");
				else
					include("inc_inicial.php");
			?>
			</div>
			<div id="rodape">Desenvolvido na disciplina de LPWEB &copy; 2014</div>
		</div>
	</body>
<?
	mysql_close ($conecta);
?>
</html>




