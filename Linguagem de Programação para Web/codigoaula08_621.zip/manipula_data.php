﻿<?
	echo "Hoje é ".date('d/m/Y')." às ".date('H:i:s')."<br/><br/>";
	
	//$timestamp = mktime(date('H'),date('i'),date('s'),date('m'),date('d')+7,date('Y'));
	//$novadata = date('d/m/Y \à\s H:i:s',$timestamp);
	
	$novadata = date('d/m/Y \à\s H:i:s',strtotime('+7 days'));

	echo "Daqui uma semana será {$novadata}";
?>