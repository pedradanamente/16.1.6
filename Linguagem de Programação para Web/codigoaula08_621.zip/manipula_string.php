﻿<?
	// Escreva um programa que armazene uma string em uma variável e remova todos os caracteres desta string que são iguais a "a". Ao final, o programa deve imprimir a quantidade de caracteres removidos e a string modificada.
	
	
	$str = "Escreva um programa que armazene uma string em uma variável e remova todos os caracteres desta string que são iguais a \"a\". Ao final, o programa deve imprimir a quantidade de caracteres removidos e a string modificada.";
	
	$total = strlen($str);

	echo "<b>String:</b> {$str} <br/><br/>";
	echo "<b>Total de caracteres:</b> {$total}<br/><br/>";

	$str = str_replace('a','',$str);

	echo "<b>String formatada:</b> {$str}<br/><br/>";

	$totalnova = strlen($str);

	$totalremovido = $total - $totalnova;

	echo "<b>Total de caracteres do texto formatado:</b> {$totalnova}<br/><br/>";
	echo "<b>Total de caracteres removidos:</b> {$totalremovido}<br/><br/>";

?>