﻿<style>
p {
	background-color: linen;
	border-style: double;
}
</style>

<? 
	$link = "http://g1.globo.com/dynamo/rss2.xml";
	$xml = simplexml_load_file($link) -> channel;
	
	foreach($xml -> item as $item){ 
		//$date = date('d/m/Y', strtotime($item->pubDate));
?>
	<p>
	<strong><a href="<? echo ($item -> link) ?>" title="<? echo ($item -> title); ?>"><? echo ($item -> title); ?></a></strong><br />
	<strong>Descrição:</strong><br /> <? echo ($item -> description) ?><br />
	<strong>Data:</strong> <? echo ($date); ?><br />
	</p>
<?
	}
?>