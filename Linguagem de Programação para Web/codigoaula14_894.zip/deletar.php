﻿<?
	$servidor="localhost"; $login="root"; $senha=""; $base = "aula";
	$conecta = mysql_connect($servidor, $login, $senha) or die ('Erro: '. mysql_error());
	mysql_select_db($base, $conecta) or die ('Erro: '. mysql_error());
	$sql = "DELETE FROM cds WHERE idCD = 24";
	$result = mysql_query($sql, $conecta) or die ('Erro no SQL: '. mysql_error());
	if ($result) 
		header("location: index.php?acao=deletarOk");
	else
		header("location: index.php?acao=erroDeletar");
	mysql_close ($conecta);
?>