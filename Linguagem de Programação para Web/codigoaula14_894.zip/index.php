<?
	$servidor="localhost"; $login="root"; $senha=""; $base = "aula";
	$conecta = mysql_connect($servidor, $login, $senha) or die ('Erro: '. mysql_error());
	mysql_select_db($base, $conecta) or die ('Erro: '. mysql_error());
	$sql = "SELECT * FROM CDs where Categoria='Blues'";
	$result = mysql_query($sql, $conecta) or die ('Erro no SQL: '. mysql_error());
	echo "<h1> Primeira conex�o ao BD {$base} </h1>";
	echo "<h3> Vou fazer a seguinte consulta: {$sql} </h3>";
	while($consulta = mysql_fetch_array($result)) { 
		echo " > {$consulta['nomeCd']} - {$consulta['Categoria']} <br/>"; 
	}
	echo "<h4> Encontrados ".mysql_num_rows ( $result )." registros na tabela</h4>";
	mysql_free_result($result); 
	mysql_close($conecta);
?>