﻿<?php
/* --------------------------------------------------------------------------------------------------- *
6) [0,7] Escreva um algoritmo PHP que crie um array multidimensional de carros onde o 
índice será a marca (VW, GM, Fiat, Ford) e para cada uma dessas marcas/posições 
adicione quatro veículos. Depois imprima o carro dois da VW, o carro um da GM, o carro 
quatro da Fiat e o carro três da Ford.
* ---------------------------------------------------------------------------------------------------- */	
$carros = array(
	"VW" => 
		array (
			0 => "Fusca", 
			1 => "Jetta",
			2 => "Golf",
			3 => "Gol"),
	"GM" =>
		array (
			0 => "Cruze",
			1 => "S10",
			2 => "Onix",
			3 => "Prisma"),
	"FIAT" =>
		array (
			0 => "Palio",
			1 => "Strada",
			2 => "Punto",
			3 => "Siena"),
	"FORD" =>
		array (
			0 => "Fiesta",
			1 => "Ka",
			2 => "Fusion",
			3 => "Focus")
);

$t=count($carros);
foreach ($carros as $key => $elemento)
{
	for($i=0;$i<$t;$i++)
	{
		if($i==0)
			echo "<strong>{$key}</strong> ";
			
		if(($key == "VW")&&($i==1) || ($key == "GM")&&($i==0) || ($key == "FIAT")&&($i==3) || ($key=="FORD")&&($i==2))
			echo "{$carros[$key][$i]} <br/><br/>";
	}
}

?>