<?php

/*
	Correto.
	+0,4
*/

ini_set('default_charset','UTF-8');
/* --------------------------------------------------------------------------------------------------- *
4) [0,4] Escreva um algoritmo PHP que receba uma string com o seu nome, encontre o 
número total de caracteres desta e imprima todos os números que existem entre 0 e o 
número total, exemplo:
Nome = “Taciano Balardin de Oliveira”
Caracteres = 28
Imprime: 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27
* ---------------------------------------------------------------------------------------------------- */

$nome = "Sistemas de Informação";
echo "Nome: {$nome} <br/> Caracteres: ".strlen($nome)." <br/>";
for ($x = 1; $x < strlen($nome); $x++)
	echo $x." ";
?>