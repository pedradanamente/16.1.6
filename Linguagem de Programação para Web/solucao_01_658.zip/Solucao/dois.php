<?php
/* --------------------------------------------------------------------------------------------------- *
2) [0,4] Escreva um algoritmo PHP que gere um valor aleatório entre 5 e 15 e calcule o seu 
fatorial (!), sabendo que fatorial de um número é: 
7! = 7*6*5*4*3*2*1
4! = 4*3*2*1
* ---------------------------------------------------------------------------------------------------- */

$fatorial = rand(5,15);
$valor = $fatorial;

for($i=$fatorial-1;$i>0;$i--) {
	$valor *= $i;
}

echo "{$fatorial}! = {$valor}";

?>
