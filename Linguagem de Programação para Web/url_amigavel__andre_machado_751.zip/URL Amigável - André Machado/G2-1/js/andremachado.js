/* JS SESSAO DIV ABRIR E FECHAR
-------------------------------------------- */
function MENU_OPENCLOSE() {
		$( "#details" ).toggle("slow", function() {			});
}