<h1>Página não encontrada</h1>
<hr/>
<div style="border:1px solid gray;width:300px;">
	<img src="imagens/404.png" width="300" height="150"/>
</div>
<div style="height:50px;"></div>