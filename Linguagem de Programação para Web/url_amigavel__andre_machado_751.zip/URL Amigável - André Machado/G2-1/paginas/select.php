<img class="fl" src="imagens/inicial.png" width="100" height="100"/>
<h1 >Select (ou Consultar)</h1>
<hr/>
<button class="mostrar" onclick="MENU_OPENCLOSE()">DETALHES</button>
<div id="details" class="details">
	<ul>
		<li><strong>Subconjunto:</strong> DML - Linguagem de Manipulação de Dados</li>
		<li><strong>Função:</strong> Consultas</li>
		<li><strong>Descrição do comando:</strong> é o principal comando usado em SQL para realizar consultas a dados pertencentes a uma tabela.</li>
		<li><strong>Exemplo:</strong> <pre>SELECT * FROM table_name;</pre></li>
	</ul>
	<hr/>
</div>
<div style="height:50px;"></div>