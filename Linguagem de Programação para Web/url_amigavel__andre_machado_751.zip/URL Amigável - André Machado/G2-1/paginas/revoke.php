<img class="fl" src="imagens/inicial.png" width="100" height="100"/>
<h1 >Revoke</h1>
<hr/>
<button class="mostrar" onclick="MENU_OPENCLOSE()">DETALHES</button>
<div id="details" class="details">
	<ul>
		<li><strong>Subconjunto:</strong> </li>
		<li><strong>Função:</strong> </li>
		<li><strong>Descrição do comando:</strong> </li>
		<li><strong>Exemplo:</strong> <pre></pre></li>
	</ul>
	<hr/>
</div>
<div style="height:50px;"></div>