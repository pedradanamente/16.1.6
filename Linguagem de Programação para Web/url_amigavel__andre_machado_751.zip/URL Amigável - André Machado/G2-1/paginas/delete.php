<img class="fl" src="imagens/inicial.png" width="100" height="100"/>
<h1 >Delete (ou Excluir)</h1>
<hr/>
<button class="mostrar" onclick="MENU_OPENCLOSE()">DETALHES</button>
<br/>
<div id="details" class="details">
	<ul>
		<li><strong>Subconjunto:</strong> DML - Linguagem de Manipulação de Dados</li>
		<li><strong>Função:</strong> Exclusões</li>
		<li><strong>Descrição do comando:</strong> permite remover linhas existentes de uma tabela.</li>
		<li><strong>Exemplo:</strong> <pre>DELETE FROM table_name WHERE campo = 7;</pre></li>
	</ul>
	<hr/>
</div>
<div style="height:50px;"></div>