<html>
	<head>
		<title>Edi��o TXT</title>
	</head>
	<body>
		<form action="save.php" method="post">
		<font face="Verdana" size="2">Conte�do: <br>
		<?php include "arquivos/{$_POST['nome']}.txt"; ?>
		</form>
	</body>
</html>