<html>
	<head>
		<title>Manipula��o TXT</title>
	</head>
	<body>
		<form action="salva.php" method="post">
			<p>Nome: <input type="text" name="nome" required /></p>
			
			<p>Conte�do: </p>
			<textarea name="conteudo"><?php include "arquivos/texto.txt"; ?></textarea>
	
			<br/><br/>
			<input type="submit" name="salvar" value="Salvar Novo">
		</form>
	</body>
</html>

<?php
	echo "<br /><br />";
	$path = "arquivos/";
	$diretorio = dir($path);
	
	echo "Lista de Arquivos do diret�rio '<strong>".$path."</strong>':<br />";
	while($arquivo = $diretorio -> read()){
		echo "<a href='".$path.$arquivo."'>".$arquivo."</a><br />";
	}
	$diretorio -> close();
?>