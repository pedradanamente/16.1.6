<?php
	$conteudo = $_POST['conteudo'];
	$texto = "arquivos/{$_POST['nome']}.txt";
	$Arquivo = fopen($texto, 'w');
	fwrite($Arquivo, $conteudo);
	fclose($Arquivo);
?>
	<p>TXT salvo com sucesso! <br /></p>
	<p>Clique <a href="index.php">aqui</a> para voltar.</p>