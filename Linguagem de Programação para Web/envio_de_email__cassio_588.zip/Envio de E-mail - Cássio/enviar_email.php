﻿<?php
    require_once('class.phpmailer.php');	
    $mail = new PHPMailer();
	//PHPMailer é um componente de envio de e-mail para servidores que exigem autenticação SMTP.
   
    $mail->Username =  $_POST ['remetente'];// E-mail do Remetente
    $mail->Password = $_POST ['senha']; // Senha do Remetente 
    $mail->FromName = "Cassio Aires Jaques"; // Nome do Remetente

    $mail->Subject = $_POST ['assunto']; // Assunto do e-mail
    $mail->Body = $_POST ['mensagem']; // Mensagem
	$mail->AddAddress($_POST['mail']); // Destinatário
	
	// Anexos    
    $mail->AddAttachment($_POST['arquivo']);  // Insere um anexo 
	
    $mail->Host = "ssl://smtp.gmail.com"; // Protocolo usado para o envio de e-mails
    $mail->Port = 465;
    $mail->IsSMTP();
    $mail->SMTPAuth = true; // Autenticação SMTP
    $mail->From = $mail->Username;
    if(!$mail->Send())
            echo "Mailer Error: " . $mail->ErrorInfo;
    else
            echo "E-mail foi enviado";
?>