<?php
	echo "<form action='form_mail.php' method='post'>";
	
	echo "Acessar E-mail: <br/><br/>";
	
	    echo "E-Mail: <input type='text' id='remetente' name='remetente' /><br/>";
	    echo "Senha: <input type='password' id='senha' name='senha' /><br/><br/>";	
	
		echo "<input type='submit' id='enviar' name='Entrar' value='Enviar'/>";
	
	echo "</form>";	
	
?>