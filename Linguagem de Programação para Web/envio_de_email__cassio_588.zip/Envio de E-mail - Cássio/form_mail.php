<?php    
	
    $senha = md5($_POST['senha']);
	//md5 é uma função do PHP usada para criptografar, usada geralmente para scripts de login.
	$login = $_POST['remetente'];
	
	if ($senha == '60c85a789b9bad80d133edbcc8ad115c' && $login == 'kassio.jakesjakes@gmail.com')
	   	{
			echo "Enviar um novo e-mail<br/>";

			echo "<form action='enviar_email.php' method='post'>";	

			echo "<input type='hidden' id='remetente' name='remetente' value='$login' /><br/>";	
			echo "<input type='hidden' id='senha' name='senha' value='{$_POST['senha']}' /><br/>";	
	
			echo "Assunto: <input type='text' id='assunto' name='assunto' /><br/>";
			echo "Para: <input type='text' id='mail' name='mail' /><br/>";
			echo "Anexo: <input type='file' id='arquivo' name='arquivo' /><br/>";
			echo "Mensagem:<br/><textarea name='mensagem' id='mensagem' col='10' row='100'></textarea> <br/>";
			echo "<input type='submit' id='enviar' name='enviar' value='Enviar'/>";
	
			echo "</form>";
	
		}
	else
	echo "Senha ou Login Invalido";
	
	
?>