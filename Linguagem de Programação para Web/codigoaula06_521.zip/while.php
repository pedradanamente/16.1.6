﻿<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title>Exercício While</title>
</head>
	<body>
	<?
		// gera um número inteiro aleatório: rand(valor minimo,valor maximo);
		$teste = rand(1,20);

		// imprime na tela o valor da variável teste
		var_dump($teste);
		var_dump($valor);

		// executa o laço de repetição enquanto $valor for menor que teste
		while($valor < $teste)
		{
			// incrementa o valor da variável $valor, o mesmo que ($valor = $valor + 1;)
			$valor++;
			// $valor % 2 --> testa se o resto da divisão de valor por 2 é igual a zero
			if($valor%2==0)
				echo "Número {$valor} é par; <br/>";
			else
				echo "Número {$valor} é impar; <br/>";
		}
	?>
	</body>
</html>





