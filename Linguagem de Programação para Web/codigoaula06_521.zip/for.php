﻿<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title>Exercício For</title>
</head>
	<body>
	<?
		// gera um número inteiro aleatório: rand(valor minimo,valor maximo);
		$teste = rand(1,20);

		// imprime na tela o valor da variável teste
		var_dump($teste);

		// laço de repetição progressivo
		echo "<h3>Contagem Progressiva</h3>";
		for($cont=1; $cont<=$teste; $cont++)
		{
			echo "{$cont}<br/>";
		}

		// laço de repetição regressivo
		echo "<h3>Contagem Regressiva</h3>";
		for($cont=$teste; $cont>0; $cont--)
		{
			echo "{$cont}<br/>";
		}
	?>
	</body>
</html>





