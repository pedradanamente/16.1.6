<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title>Meu Primeiro C�digo PHP</title>
</head>
	<body>
	<?
		// Minhas primeiras linhas em php!
		$nome = 'Taciano';
		echo '<h1>Hello World!</h1>';
		echo "Meu nome �: {$nome} <br/><br/>";

		print("Hello {$nome}!");
		
		$vetor = array('Palio','Gol','Corsa','Fiesta','Uno');
		var_dump($vetor);

		echo "<pre>";
		print_r($vetor);
		echo "</pre>";

		var_dump($nome);
	?>
	</body>
</html>





