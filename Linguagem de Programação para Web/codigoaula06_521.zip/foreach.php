﻿<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title>Exercício Foreach</title>
</head>
	<body>
	<?
		// cria um array e atribui valores a ele
		$frutas = array('Maçã','Banana','Melão','Melancia','Abacate');

		// imprime na tela o valor da variável frutas
		var_dump($frutas);

		// imprime cada um dos valores do array frutas
		foreach($frutas as $valor)
		{
			echo "{$valor}<br/>";
		}

		foreach($frutas as $indice => $valor)
		{
			echo "{$indice} => {$valor}<br/>";
		}

	?>
	</body>
</html>





