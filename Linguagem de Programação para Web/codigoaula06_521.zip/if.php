﻿<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title>Exercício IF</title>
</head>
	<body>
	<?
		$g1 = 6;
		$g2 = 5;

		echo "Nota de G1: {$g1} <br/>";
		echo "Nota de G2: {$g2} <br/>";

		$media = ($g1 + ($g2 * 2)) / 3;
		// number_format(valor, casas decimais, 'separador decimal', 'separador milhar');
		$media = number_format($media, 2, ',','.');

		echo "Média Final: {$media} <br/>";

		if($media >= 6)
			echo "Aluno Aprovado!";
		elseif($media < 6)
			echo "Aluno Reprovado!";
	?>
	</body>
</html>





