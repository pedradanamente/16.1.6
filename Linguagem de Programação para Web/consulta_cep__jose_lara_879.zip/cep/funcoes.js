	/*função consultacep é responsável por enviar e o Cep
	para o endereço dos correios e receber o arquivo JSONP 
	assim que for retirado o cursor do input text.
	*/
	function consultacep(cep){
		cep = cep.replace(/\D/g,"")
		url="http://cep.correiocontrol.com.br/"+cep+".js"//a variavel url esta recebendo o endereço do site e o cep digitado
		s=document.createElement('script')//função de entrada de algum elemento de texto
		s.setAttribute('charset','utf-8')
		s.src=url
		document.querySelector('head').appendChild(s)
	}
	
	/*função correiocontrolcep é responsável por receber o arquivo JSONP 
	que a consulta anterior retorna da url.
	Se o arquivo não for falso retorna uma mensagem Cep não encontrado
	Caso contrario preenche os campos.
	*/
	function correiocontrolcep(valor){
		if (valor.erro) {
		alert('Cep não encontrado');       
		return;
		};
		document.getElementById('logradouro').value=valor.logradouro//faz uma verificação se a variavel não está vazia.
		document.getElementById('bairro').value=valor.bairro//pega o elemento do documento
		document.getElementById('localidade').value=valor.localidade//para utilizar esta dever ter atribuido um id
		document.getElementById('uf').value=valor.uf
	}