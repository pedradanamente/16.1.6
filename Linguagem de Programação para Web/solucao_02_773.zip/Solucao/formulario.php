﻿<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title>Atividade 02</title>
</head>
<body>
	<form action="processa.php" method="POST"/>
	<?
		$alunos = 5;

		for($x=1; $x<=$alunos; $x++) 
		{
			echo "<h2>Aluno {$x}</h2>";
	?>		
			<p>Nome: <input type="text" name="nome<?=$x?>" value="Aluno 0<?=$x?>" size="50"/></p>
			<p>Idade: <input type="number" name="idade<?=$x?>" max="100" min="16" value="<?=rand(20,30)?>" size="10"/></p>
			<p>
				Sexo: <input type="radio" name="sexo<?=$x?>" value="Masculino" id="M<?=$x?>" /> <label for="M<?=$x?>">Masculino</label>
				<input type="radio" name="sexo<?=$x?>" value="Feminino" id="F<?=$x?>" /> <label for="F<?=$x?>">Feminino</label>
				
			</p>
			<p>
			<select name="curso<?=$x?>">
				<option value="1">Administração</option>
				<option value="2">Ciências Contábeis</option>
				<option value="3">Sistemas de Informação</option>
			</select>
			</p>
	<? 
		}
	?>				
		<p>
			<input type="submit" value="Enviar" name="enviar"/>
		</p>
				
	</form>		
</body>
</html>