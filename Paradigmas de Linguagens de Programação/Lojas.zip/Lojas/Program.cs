﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lojas
{
    class Program
    {
        static void Main(string[] args)
        {
            //Loja 10 reau
            Loja objLoja = new Loja("Loja 10 reáu");
            //produto da loja acima
            Produto objProd = new Produto();
            objProd.Nome = "Caneca";
            objProd.Valor = 5;
            objProd.Desconto = 1;
            //chmar metodo de impressão
            objLoja.Imprimir(objProd);
            Console.ReadKey();

            Console.WriteLine();
            Console.WriteLine();
            //Loja tudão
            LojaVarejo objLojaVarejo = new LojaVarejo("Loja tudão");
            //instanciar novo objeto para loja tudão
            objProd = new Produto();
            objProd.Nome = "Sofá";
            objProd.Valor = 500;
            objProd.Desconto = 50;
            //chmar metodo de impressão
            objLojaVarejo.Imprimir(objProd, 4);
            Console.ReadKey();
        }
    }
}
