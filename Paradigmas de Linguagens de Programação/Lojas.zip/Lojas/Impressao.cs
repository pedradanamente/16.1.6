﻿using System;

namespace Lojas
{
    public class Impressao:Venda
    {
        public Impressao()
        {
        }

        public Impressao(Loja objLoja, Produto objProd)
        {
            Imprimir(objLoja, objProd);
        }

        public Impressao(Loja objLoja, Produto objProd, double juro, int parcelas)
        {
            double valor = DescontoParcelado(parcelas, objProd.Valor, objProd.Desconto);
            Venda objVenda = new Venda(juro, parcelas, valor);
            Imprimir(objLoja, objProd, objVenda);
        }

        public Impressao(Loja objLoja, Produto objProd, int parcelas)
        {
            double valor = DescontoParcelado(parcelas, objProd.Valor, objProd.Desconto);
            Venda objVenda = new Venda(parcelas, valor);
            Imprimir(objLoja, objProd, objVenda);
        }

        private void Imprimir(Loja objLoja, Produto objProd)
        {
            Console.WriteLine("=".PadRight(21, '='));
            Console.WriteLine("|" + objLoja.Nome.PadRight(20, ' ') + "|");
            Console.WriteLine("|" + string.Format("Produto: {0}", objProd.Nome).ToString().PadRight(20, ' ') + "|");
            Console.WriteLine("|" + string.Format("Valor: {0}", objProd.Valor).ToString().PadRight(20, ' ') + "|");
            Console.WriteLine("|" + string.Format("Desconto: {0}", objProd.Desconto).ToString().PadRight(20, ' ') + "|");
            Console.WriteLine("|" + string.Format("Total: {0}", objProd.CalcularDesconto(objProd.Valor, objProd.Desconto)).ToString().PadRight(20, ' ') + "|");
            Console.WriteLine("=".PadRight(21, '='));
        }

        private void Imprimir(Loja objLoja, Produto objProd, Venda objVenda)
        {
            Console.WriteLine("==".PadRight(21, '='));
            Console.WriteLine("|" + objLoja.Nome.PadRight(20, ' ') + "|");
            Console.WriteLine("|" + string.Format("Produto: {0}", objProd.Nome).ToString().PadRight(20, ' ')  + "|");
            Console.WriteLine("|" + string.Format("Valor: {0}", objProd.Valor).ToString().PadRight(20, ' ') + "|");
            Console.WriteLine("|" + string.Format("Desconto: {0}", objProd.Desconto).ToString().PadRight(20, ' ') + "|");

            Console.WriteLine("|" + string.Format("Juros: {0}", objVenda.TxJuro).ToString().PadRight(20, ' ') + "|");
            Console.WriteLine("|" + string.Format("Parcelas: {0}", objVenda.Parcelas).ToString().PadRight(20, ' ') + "|");
            Console.WriteLine("|" + string.Format("Total: {0}", objVenda.ValorTotal).ToString().PadRight(20, ' ') + "|");
            Console.WriteLine("==".PadRight(21, '='));
        }

        private double DescontoParcelado(int parcelas, double valor, double desconto)
        {
            if (parcelas > 3)
                return valor;
            else
                return valor - desconto;
        }
    }
}
