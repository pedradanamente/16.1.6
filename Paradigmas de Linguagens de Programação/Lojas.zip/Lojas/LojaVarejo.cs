﻿
namespace Lojas
{
    public class LojaVarejo:Loja
    {
        public LojaVarejo(string nome)
        {
            Nome = nome;
        }

        public void Imprimir(Produto objProd, double juro, int parcelas)
        {
            new Impressao(new Loja(Nome), objProd, juro, parcelas);   
        }

        public void Imprimir(Produto objProd, int parcelas)
        {
            new Impressao(new Loja(Nome), objProd, parcelas);
        }
    }
}
