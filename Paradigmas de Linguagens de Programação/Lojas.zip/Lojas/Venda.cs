﻿using System;

namespace Lojas
{
    public class Venda
    {
        public double TxJuro { get; set; }
        public int Parcelas { get; set; }
        public double ValorTotal { get; set; }

        public Venda()
        {

        }

        public Venda(double juro, int parcelas, double valor)
        {
            TxJuro = juro / 100;
            this.Parcelas = parcelas;
            ValorTotal = ValorParcelado(valor);
        }

        public Venda(int parcelas, double valor)
        {
            TxJuro = 0.02;
            this.Parcelas = parcelas;
            ValorTotal = ValorParcelado(valor);
        }

        private double ValorParcelado(double valor)
        {
            return valor * Math.Pow((1 + TxJuro), Parcelas);
            
        }

    }
}
