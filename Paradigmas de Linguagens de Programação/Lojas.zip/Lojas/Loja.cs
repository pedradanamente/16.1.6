﻿
namespace Lojas
{
    public class Loja:Impressao
    {
        public string Nome { get; set; }

        public Loja() { }

        public Loja(string nome)
        {
            Nome = nome;
        }

        public void Imprimir(Produto objProd)
        {
            new Impressao(new Loja(Nome), objProd);
        }
    }
}
