﻿
namespace Lojas
{
    public class Produto
    {
        public string Nome { get; set; }
        public double Valor { get; set; }
        public double Desconto { get; set; }

        public double CalcularDesconto(double valor, double desconto)
        {
            return valor - desconto;
        }
    }
}
