#include <stdio.h>
#include <stdlib.h>
#include "variaveis.h"
#include "resultado.h"
#include "operacoes.h"

//criar as funcoes inicias
int Menu(void)
{
	int invalido = FALSE, acao, opcao;
	do
	{
		if(invalido)
			printf("\n Operacao invalida");
		else
		{
			system("clear");
			printf("\n Operacoes:");
			printf("\n 1 Somar:");
			printf("\n 2 Subtrair:");
			printf("\n 3 Multiplicar:");
			printf("\n 4 Dividir:");
			printf("\n 5 Encerrar:");
			printf("\n Informe a opcao: ");
		}
		invalido = FALSE;
		scanf("%d", &opcao);
		switch(opcao)
		{
		case 1:
			acao = SOMAR;
			break;
		case 2:
			acao = SUBTRAIR;
			break;
		case 3:
			acao = MULTIPLICAR;
			break;
		case 4:
			acao = DIVIDIR;
			break;
		case 5:
			acao = TERMINAR;
			break;
		default:
			invalido = TRUE;
			break;
		}
		
	}	
	while(invalido);
	return acao;
}


float valor1, valor2;




void InformarValores()
{
	system("clear");
	printf("INFORME O VALOR 1: ");
	scanf("%f", &valor1);
	printf("INFORME O VALOR 2: ");
	scanf("%f", &valor2);
}


void main(void){
		
	int acao;
	while((acao=Menu())!=TERMINAR)
	{
		InformarValores();
		switch(acao)
		{
		case SOMAR:
			Somar(valor1, valor2);
			break;
		case SUBTRAIR:
			Subtrair(valor1, valor2);
			break;
		case MULTIPLICAR:
			Multiplicar(valor1, valor2);
			break;
		case DIVIDIR:
			Dividir(valor1, valor2);
			break;
		}
	}
}

