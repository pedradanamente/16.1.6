void ApresentarResultado(float resultado, int opcao)
{
	switch(opcao)
	{
	case SOMAR:
		printf("\n RESULTADO DA SOMA: %f", resultado);
		break;
	case SUBTRAIR:
		printf("\n RESULTADO DA SUBTRACAO: %f", resultado);
		break;
	case MULTIPLICAR:
		printf("\n RESULTADO DA MULTIPLICACAO: %f", resultado);
		break;
	case DIVIDIR:
		printf("\n RESULTADO DA DIVISAO: %f", resultado);
		break;
	}	
}