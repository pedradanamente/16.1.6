void Somar(float valor1, float valor2)
{
	ApresentarResultado(valor1+valor2, SOMAR);

}
void Subtrair(float valor1, float valor2)
{
	ApresentarResultado(valor1-valor2, SUBTRAIR);
}
void Multiplicar(float valor1, float valor2)
{
	ApresentarResultado(valor1*valor2, MULTIPLICAR);
}
void Dividir(float valor1, float valor2)
{
	float resultado=0;
	if(valor2!=0)
		resultado = valor1 / valor2;
	ApresentarResultado(resultado, DIVIDIR);
}