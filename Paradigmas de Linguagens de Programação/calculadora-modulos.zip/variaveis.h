//variaveis(falsos numeradores) de controle

#define FALSE 0
#define TRUE 1

#define SOMAR 2
#define SUBTRAIR 3
#define MULTIPLICAR 4
#define DIVIDIR 5
#define TERMINAR 6